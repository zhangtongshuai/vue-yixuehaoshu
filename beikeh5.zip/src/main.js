import Vue from 'vue'
import App from './App'
import router from './router'
import store from './vuex/store'
import axios from 'axios'
import VueClipboard from 'vue-clipboard2'
import customMethods from './assets/js/customMethods'
import getCont from './assets/js/getCont'
import wxConfig from '@/assets/js/wxConfig.js'

import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import locache from '@/assets/js/locache'
import './assets/css/style.css'

Vue.use(VueClipboard)
Vue.use(router)
Vue.use(ElementUI)
Vue.config.productionTip = false
Vue.prototype.$locache = locache
Vue.prototype.$http = axios
Vue.prototype.$customMethods = customMethods
Vue.prototype.$getData = getCont
Vue.prototype.wxConfig = wxConfig
// console.log(getCont)
/* eslint-disable no-new */

new Vue({
  el: '#app',
  router,
  store,
  render: h => h(App)
})
