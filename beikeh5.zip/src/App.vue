<template>
  <div id="app">
    <div id="IframeBox" v-if="isIframe">
      <iframe :src = "IframeSrc" frameborder="0" id="Iframe" ></iframe>
      </iframe>
    </div>
    <router-view></router-view>
  </div>

</template>
<script>
export default {
  name: 'App',
  data () {
    return {
      isIframe: false,
      IframeSrc: '',
      reqGetUser: {
        module: 'member',
        method: 'qq.get_user',
        request_mode: 'post',
        openid: '',
        access_token: ''
      },
      reqUser: {
        module: 'member',
        method: 'user.show',
        request_mode: 'post'
      },
      reqCode: {
        key: 'wx_first',
        module: 'member',
        method: 'wechat.get_user',
        request_mode: 'get'
      }
    }
  },
  created () {
    this.isAuthorized()
    this.userLogin()
  },

  methods: {
    callback (data) {
    },
    userLogin () {
      let _this = this
      if (this.$locache.get('userData')) {
        console.log("授权成功1")
        this.$store.state.saveUData = this.$locache.get('userData')
        let herf = this.$locache.get('refereeUrl')
        this.$router.push({path: herf.pathname + herf.search})
      } else {
        if (_this.isAuthorized()) {
          console.log('微信')
          this.isIframe = false
          // 微信授权授权;
          if (location.search != '') {
            // 获取到code
            console.log(location.search.split('=')[0])
            if (location.search.split('=')[0] == '?referee') {
              this.$locache.set('refereeUrl', {
                pathname: location.pathname,
                search: location.search
              })
              window.location.href =
                'https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx1048afd03302531b&redirect_uri=http%3a%2f%2fbook.zhongmeiyixue.com%2f&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect'
            } else {
              let urlCode = location.search.split('?')[1].split('&')[0]
              let code = urlCode.split('=').pop()
              if (code == '') {
                console.log("重新获取code");
                window.location.href =
                  'https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx1048afd03302531b&redirect_uri=http%3a%2f%2fbook.zhongmeiyixue.com%2f&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect'
              } else {
                console.log('已获取code')
                _this.$getData({code: code}, _this.reqCode).then(res => {
                  console.log(res)
                  if (res.code === '200') {
                    let result = res.result
                    if (result != null) {
                      console.log('授权成功2')
                      _this.$locache.set('userData', result)
                      _this.$store.state.saveUData = result
                      let herf = _this.$locache.get('refereeUrl')
                      _this.$router.push({path: herf.pathname + herf.search})
                    }
                  } else {
                    alert('登陆失败')
                  }
                })
                // this.$http.get(url).then(response => {
                //   // 请求用户数据
                //   console.log(response)
                //   if (response.data.code == '200') {
                //     let result = response.data.result
                //     if (result != null) {
                //       console.log("授权成功2");
                //       _this.$locache.set('userData', result)
                //       _this.$store.state.saveUData = result
                //       let herf = _this.$locache.get('refereeUrl')
                //       _this.$router.push({path: herf.pathname + herf.search})
                //     }
                //   } else {
                //     alert('登陆失败')
                //   }
                // })
              }
            }
            // console.log(code);
          } else {

            window.location.href =
              'https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx1048afd03302531b&redirect_uri=http%3a%2f%2fbook.zhongmeiyixue.com%2f&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect'
          }
          // 微信授权授权End;
        } else {
          // QQ登陆
          console.log('QQ')
          if (location.hash != '') {
            this.isIframe = false
            let access_token = location.hash
              .substring(1)
              .split('&')[0]
              .split('=')[1]

            if (access_token != '') {
              // console.log(access_token);
              let expires = location.hash
                .substring(1)
                .split('&')[1]
                .split('=')[1]
              let getOpenid =
                'https://graph.qq.com/oauth2.0/me?access_token=' + access_token
              // console.log(url);
              $.ajax({
                type: 'GET',
                url: getOpenid,
                dataType: 'jsonp',
                jsonp: 'callback',
                jsonpCallback: 'callback',
                success: function (data) {
                  _this.reqGetUser.access_token = access_token
                  _this.reqGetUser.openid = data.openid
                  _this.$getData(_this.reqGetUser).then(res => {
                    console.log(res)
                    let status = res.status
                    let result = res.result
                    if (status == 'success' && result != null) {
                      // alert("已授权");
                      _this.$locache.set('userData', result)
                      _this.$store.state.saveUData = result
                      // console.log(this.$store.state);
                    }
                  })
                }
              })
            }
          } else {
            this.toLogin()
          }
        }
      }
    },
    toLogin () {
      // qq登陆
      this.isIframe = true
      this.IframeSrc =
        'https://graph.qq.com/oauth2.0/authorize?response_type=token&state=test&client_id=101408647&redirect_uri=http%3a%2f%2fbook.zhongmeiyixue.com%2findex'
    },
    isAuthorized () {
      let ua = window.navigator.userAgent.toLowerCase()
      if (ua.match(/MicroMessenger/i) == 'micromessenger') {
        this.$store.state.isAuthorized = true
        return true
      } else {
        this.$store.state.isAuthorized = false
        return false
      }
    }
  }
}
</script>
