import axios from 'axios'
import md5 from 'js-md5'
const getData = (
  params = {},
  options
) => {
  let timestamp = Date.parse(new Date()) / 1000;
  let sign = 'wx_first' + timestamp + 'ezYQAe5UEi5UMHtY'
  sign = md5(sign);
  let signCont = {
    key: 'wx_first',
    sign: sign,
    timestamp: timestamp
  }
  let _data = Object.assign(signCont, options)
  let _params = params;
  return axios({
      method: "post",
      url: "http://api.store.zhongmeiyixue.com/api/index",
      data: _data,
      params: _params
      //withCredentials: _options.withCredentials
    })
    .then(res => {
      let _res = res.data
      return _res
    })
    .catch(e => {
      return e
    })
}

export default getData
