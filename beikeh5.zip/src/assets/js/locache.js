export default {
  set(name,data){
    let timestamp = new Date().getTime()+ 1000*60*60;
    let DueTime = timestamp + 1000*60*60*24;
    console.log(timestamp)

    let savedata = Object.assign({},data,{DueTime:DueTime})
    localStorage.setItem(name, JSON.stringify(savedata));
  },
  get(name){
    let timestamp = new Date().getTime();
    let data = JSON.parse(localStorage.getItem(name));
    if(data == null){
      return false
    }else if(data.DueTime < timestamp || data.DueTime == null || data.DueTime == undefined){
      return false
    }else{
      return data
    }
  }
}
