import md5 from 'js-md5'

export default {
  signCont() {
    let timestamp = Date.parse(new Date()) / 1000;
    let sign = 'wx_first' + timestamp + 'ezYQAe5UEi5UMHtY'
    sign = md5(sign);
    let signCont = {
      key: 'wx_first',
      sign: sign,
      timestamp: timestamp
    }
    return signCont
  },
  saveNavData(storageName, res) {
    if (typeof (res) === 'undefined') {
      console.log('555')
    } else {
      let navValue = JSON.stringify(res);
      sessionStorage.setItem(storageName, navValue);
    }
    //console.log(res);
  },
  saveCookie(cookieName, cookieValue, cookieDates) {

    let storageValue = 'cookieValue=' + cookieValue + '&expires=' + Date.parse(new Date())

    localStorage.setItem(cookieName, storageValue)
  },
  getAllUrlPram: function (url) { //获取code内容
    let arr = url.split("&"); //将字符串以&为分隔符转化为数组
    let obj = {}; //定义一个空对象
    for (let i = 0; i < arr.length; i++) {
      let str0 = arr[i].split("=")[0], //将获得数组中的每一个元素字符串转换成用"="分割的数组，数组第一个元素即为key
        str1 = arr[i].split("=")[1]; //将获得数组中的每一个元素字符串转换成用"="分割的数组，数组第一个元素即为value
      obj[str0] = decodeURI(str1); //由于url中使用的是转义后的字符，因此必须使用decodeURI进行解码
    }
    return obj;
  },
}
