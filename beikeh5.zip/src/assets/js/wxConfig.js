import wx from 'weixin-js-sdk'

const wxConfig = (
  params = {},
  options
) => {
  wx.config({
    debug: true,
    appId: 'wx1048afd03302531b',
    timestamp: options.timestamp,
    nonceStr: options.noncestr,
    signature: options.signature,
    jsApiList: ['onMenuShareTimeline', 'onMenuShareAppMessage', 'onMenuShareQQ', 'onMenuShareWeibo', 'onMenuShareQZone']
  })
  let links = params.url
  let title = '请关注公众号'
  let desc = '请关注公众号'
  let imgUrl = ''
  wx.ready(function () {
    wx.onMenuShareTimeline({
      title: title, // 分享标题
      desc: desc, // 分享描述
      link: links, // 分享链接
      imgUrl: imgUrl, // 分享图标
      success: function () {
        alert('分享到朋友圈成功')
      },
      cancel: function () {
        alert('分享失败,您取消了分享!')
      }
    })
    // 微信分享菜单测试
    wx.onMenuShareAppMessage({
      title: title, // 分享标题
      desc: desc, // 分享描述
      link: links, // 分享链接
      imgUrl: imgUrl, // 分享图标
      success: function () {
        alert('成功分享给朋友')
      },
      cancel: function () {
        alert('分享失败,您取消了分享!')
      }
    })

    wx.onMenuShareQQ({
      title: title, // 分享标题
      desc: desc, // 分享描述
      link: links, // 分享链接
      imgUrl: imgUrl, // 分享图标
      success: function () {
        alert('成功分享给QQ')
      },
      cancel: function () {
        alert('分享失败,您取消了分享!')
      }
    })
    wx.onMenuShareWeibo({
      title: title, // 分享标题
      desc: desc, // 分享描述
      link: links, // 分享链接
      imgUrl: imgUrl, // 分享图标
      success: function () {
        alert('成功分享给朋友')
      },
      cancel: function () {
        alert('分享失败,您取消了分享!')
      }
    })
    wx.onMenuShareQZone({
      title: title, // 分享标题
      desc: desc, // 分享描述
      link: links, // 分享链接
      imgUrl: imgUrl, // 分享图标
      success: function () {
        alert('成功分享给朋友')
      },
      cancel: function () {
        alert('分享失败,您取消了分享!')
      }
    })
  })
  wx.error(function (err) {
    alert(JSON.stringify(err))
  })
}

export default wxConfig
