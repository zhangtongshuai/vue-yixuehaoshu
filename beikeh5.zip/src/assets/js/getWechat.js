import axios from 'axios'
import store from '@/vuex/store'
export default {
  getCode: function () { //请求code
    window.location.href = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx1048afd03302531b&redirect_uri=http%3a%2f%2fbook.zhongmeiyixue.com%2f%23&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect'
  },
  getToken(saveCode) {
    let res = {}
    let url = 'http://api.store.zhongmeiyixue.com/wechat/get_user?code=' + saveCode;
    axios.get(url).then(response => {
        //console.log(url)
        let status = response.data.status;
        let result = response.data.result;
        if (status == "success" && result != null) {
              this.$store.state.isAuthorized = true
        }
      }

    );

    return res;
  }
}
