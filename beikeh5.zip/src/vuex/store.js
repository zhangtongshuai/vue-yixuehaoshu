import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const state = {
  saveUData: {
    is_subscribe: 1, // 是否关注 0未关注 1已关注
    openid: "",
    uid: '', // 用户ID 4685456165290493,
    DueTime: ''
  },
  address: [], // 保存的地址
  isAuthorized: false, //
  saveCartId: [], // 保存的提交订单的ID
  saveMarketData: {}, // 直接购买的商品ID
  shopData: [], //
  isTop: true, // 是否需要margin
  marginTop: '50px',
  oldRouter: '', // 记录URL跳转
  RouterUrl: '', // 完整跳转记录
  parityUrl: ''
}
const mutations = {
  Authorized (state, uData) {
    state.isAuthorized = true
    state.uData = uData
  }
}
const getters = {
  isSubscribe (state) {
    if (state.isAuthorized) {
      if (state.saveUData.is_subscribe === 1) {
        return false
      } else {
        return true
      }
    } else {
      return false
    }
  }
}

export default new Vuex.Store({
  state,
  mutations,
  getters

})
