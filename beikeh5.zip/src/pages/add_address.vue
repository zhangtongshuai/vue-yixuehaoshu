<template>
  <!-- 新增收货地址 -->
  <div class="add_address">
    <div class="fill_in">
      <span>收货人</span>
      <input type="text" placeholder="请填写收货人姓名" v-model='address.consignee'>
    </div>
    <div class="fill_in">
      <span>收货人电话</span>
      <input type="text" placeholder="请填写收货人手机号码" v-model='address.mobile'>
    </div>
    <div class="fill_in">
      <span>收货地址</span>
      <div class="choice_address">
        <font>
          <el-cascader separator='' :options="options" @change="handleItemChange" :props="props" v-model="selectedAdd"></el-cascader>
        </font>
      </div>
    </div>
    <div class="fill_in">
      <span>详细地址</span>
      <textarea rows="3" placeholder="请输入详细地址信息，如道路、门牌号、小区、楼栋号、单元室等。" v-model='address.address'></textarea>
    </div>
    <div class="fill_in">
      <span>设置为默认地址</span>
      <div>
        <input type="checkbox" name="sex" id="male" class="chooseBtn" v-model='address.is_default' />
        <label for="male" class="choose-label"></label>
      </div>
    </div>
    <div class="fill_button">
      <span @click="back()"> 取消</span>
      <span @click="saveAdd()">保存</span>
    </div>
  </div>
  <!-- 新增收货地址end -->
</template>
<script>
import district from '@/assets/json/district.json'

export default {
  name: 'add_address',
  data () {
    return {
      options: [],
      props: {
        value: 'id',
        label: 'district_name',
        children: '_child'
      },
      reqAddAddress: {
        module: 'member',
        method: 'address.store',
        request_mode: 'post',
        consignee: '',
        mobile: '',
        address: '',
        is_default: 0,
        uid: '',
        province_id: '',
        city_id: '',
        district_id: '',
        province: '',
        city: '',
        district: ''
      },
      reqUpdateAddress: {
        module: 'member',
        method: 'address.update',
        request_mode: 'post',
        consignee: '',
        address_id: '',
        mobile: '',
        address: '',
        is_default: 0,
        uid: '',
        province_id: '',
        city_id: '',
        district_id: '',
        province: '',
        city: '',
        district: ''
      },
      address: {
        consignee: '',
        mobile: '',
        address: '',
        is_default: 0
      },
      selectedAdd: ['', '', ''],
      vals: [],
      now: '',
      Add: true // 更新还是新建
    }
  },
  created () {
    if (this.$route.query.address != undefined) {
      let upAddress = this.$route.query.address
      this.address = upAddress
      if (this.selectedAdd.length != 0) {
        this.Add = false
      }
      this.selectedAdd[0] = upAddress.province_id
      this.selectedAdd[1] = upAddress.city_id
      this.selectedAdd[2] = upAddress.district_id
    }

    this.options = district
    this.reqAddAddress.uid = this.$store.state.saveUData.uid
    this.reqUpdateAddress.uid = this.$store.state.saveUData.uid
  },
  beforeCreate: function () {
    document.getElementsByTagName('body')[0].className = 'bg-fff'
  },
  methods: {
    back () {
      this.$router.push({ path: '/' + this.$route.query.url })
    },
    handleItemChange (val) {
      // console.log(val);

      this.vals = this.getCascaderObj(val, this.options)

      this.reqAddAddress.province_id = this.vals[0].id
      this.reqAddAddress.province = this.vals[0].district_name
      this.reqAddAddress.city_id = this.vals[1].id
      this.reqAddAddress.city = this.vals[1].district_name
      this.reqAddAddress.district_id = this.vals[2].id
      this.reqAddAddress.district = this.vals[2].district_name
      // console.log(this.reqAddAddress);
    },
    getCascaderObj (val, opt) {
      return val.map((value, index, array) => {
        for (var itm of opt) {
          if (itm.id == value) {
            opt = itm._child
            /// /console.log(itm)
            return itm
          }
        }
        return null
      })
    },
    saveAdd () {
      if (this.Add) {

        this.reqAddAddress.consignee = this.address.consignee
        this.reqAddAddress.mobile = this.address.mobile
        this.reqAddAddress.address = this.address.address
        this.reqAddAddress.is_default = this.address.is_default
        console.log('true',this.reqAddAddress)
        this.$getData({}, this.reqAddAddress).then(res => {
          console.log(res)
          if (res.result == 1) {
            this.$router.push({ path: '/' + this.$route.query.url })
          }
        })
      } else {
        console.log(this.reqAddAddress)
        this.reqUpdateAddress.address_id = this.address.id
        console.log('false',this.reqAddAddress)
        this.reqUpdateAddress.consignee = this.address.consignee
        this.reqUpdateAddress.mobile = this.address.mobile
        this.reqUpdateAddress.address = this.address.address
        this.reqUpdateAddress.is_default = this.address.is_default
        this.reqUpdateAddress.uid = this.address.user_id
        this.reqUpdateAddress.province_id = this.address.province_id
        this.reqUpdateAddress.city_id = this.address.city_id
        this.reqUpdateAddress.district_id = this.address.district_id
        this.reqUpdateAddress.province = this.address.province
        this.reqUpdateAddress.city = this.address.city
        this.reqUpdateAddress.district = this.address.district
        this.$getData({}, this.reqUpdateAddress).then(res => {
          console.log(res)
          if (res.result == 1) {
            this.$router.push({ path: '/' + this.$route.query.url })
          }
        })
      }
    }
  }
}

</script>
