<template>
  <div>
<app-banner :listImg="listImg" ref="productBanner"></app-banner>
<!-- banner end -->

<!-- 商品名称和简介 -->
<div class="product_name">
    <div v-if="isPre" >
        <h1><span>火热预售中!!!!!</span>{{saveData.name}}</h1>
    <p class="pro_pre">
        <span>截止日期：{{saveData.presale_end_time}} </span><br>
        预售结束后，价格将调整为{{saveData.price}}元。<br>
        所有预售订单，将在{{preEndDate}}开始发货。
    </p>
    </div>
    <div v-else>
        <h1 >{{saveData.name}}</h1>
    </div>

    <div class="price">
        <div>
            <h2><span>￥</span>{{ProPrice}}</h2>
            <del>￥{{saveData.original_price}}</del>
            <h3 v-if="saveData.discount != 0">{{saveData.discount}}折</h3>
        </div>
        <h4>销量：{{saveData.sales_number}}</h4>
    </div>
    <div class="introduce">
        <ul>
            <li>
                <span class="span-nav">快递</span>
                <p>
                    <span v-if = "saveData.markets_one_fee == null || saveData.markets_one_fee.base_fee == 0">包邮<br></span>
                <span v-if = "saveData.markets_one_fee != null && saveData.markets_one_fee.base_fee != 0">快递费：{{saveData.markets_one_fee.base_fee}}元<br></span>
                <span v-if = "saveData.markets_one_fee != null && saveData.markets_one_fee.max_fee != 0"><font>满减</font>商品满{{saveData.markets_one_fee.max_fee}}元包邮</span></p>
            </li>
            <li>
                <span class="span-nav">出版日期</span>
                <p >{{saveData.produce_date}}</p>
            </li>
            <li>
                <span class="span-nav">作者</span>
                <p>{{saveData.author}}</p>
            </li>
            <li>
                <span class="span-nav">出版社</span>
                <p>{{saveData.manufactor}}</p>
            </li>
            <li>
                <span class="span-nav">页数</span>
                <p>{{saveData.pages}}</p>
            </li>
            <li>
                <span class="span-nav">ISBN/物品码</span>
                <p>{{saveData.code}}</p>
            </li>
        </ul>
    </div>
</div>
<!-- 商品名称和简介end -->

<!-- 联系供货商 -->
<div class="seller">
    <div class="seller_top" v-if="saveData.markets_one_member != null">
        <img :src = "saveData.markets_one_member.avatar">
        <div>
            <h1>{{saveData.markets_one_member.name}}</h1>
            <h2>{{saveData.markets_one_member.province_name}}{{saveData.markets_one_member.city_name}}</h2>
        </div>
    </div>
    <div class="seller_bot">
        <a class="contact_seller" @click="showContact()">联系供货商</a>
    </div>
</div>
<!-- 联系供货商end -->
<!-- 联系供货商点击弹出框 -->
<div class="seller_contact" v-if="isShow">
    <div class="seller_contact_con">
        <div class="seller_contact_con_con">
            <div class="seller_contact_top">
                <img src="@/assets/img/Popup.png">
                <a id="seller_contact_close" @click="hideContact()">×</a>
            </div>
            <div class="seller_contact_bot">
                <div class="seller_contact_ewm">
                    <img :src="saveData.markets_one_member.qrcode">
                </div>
                <a :href="'tel:' + saveData.markets_one_member.mobile" v-show="saveData.markets_one_member.mobile !=0">电话：{{saveData.markets_one_member.mobile}} <button>拨打</button></a>
                <a v-show="saveData.markets_one_member.brief != ''">公告：{{saveData.markets_one_member.brief}}</a>
                <a>地址：{{saveData.markets_one_member.province_name}}{{saveData.markets_one_member.city_name}}{{saveData.markets_one_member.address}}</a>
            </div>
        </div>
    </div>
</div>
<!-- 联系供货商点击弹出框end -->

<!-- 详情 -->
<div class="details">
    <h1>【商品详情】</h1>
    <p v-html="saveData.brief"></p>
</div>
<!-- 详情end -->

<!-- 购买 -->
<div class="subnav">
    <div class="subnav_left">
        <a class="contact_seller"  @click="showContact()">
            <img src="@/assets/img/menu6.png">
            <h4 >客服</h4>
        </a>
        <router-link to="/shopping">
            <img src="@/assets/img/menu2.png">
            <h4>购物车</h4>
        </router-link>
    </div>
    <div class="subnav_right">
        <el-button :plain="true" @click="showAttribute(1)">加入购物车</el-button>
        <el-button :plain="true" @click="showAttribute(2)">立即购买</el-button>
        <!-- <a href="#">加入购物车</a>
        <a href="order_generate.html">立即购买</a> -->
    </div>
</div>
<!-- 购买end -->
<!-- 点击商品详情  选择属性弹出框 -->
<div class="attribute" v-if = 'isNumber'>
    <div class="attribute_contact_con">
        <div class="attribute_contact_con_con">
            <div class="attribute_contact_top">
                <img src="@/assets/img/Popup.png">
                <a id="attribute_contact_close" @click="hideAttribute()">×</a>
            </div>
            <div class="attribute_contact_bot">
                <p>选择商品数量</p>
                <div class="choice_attribute">
                    <span>数量</span>
                    <div>
                        <button @click="ReducNum()">-</button>
                        <input type="text" v-model="market_number">
                        <button @click="AddNum()">+</button>
                    </div>
                </div>
            </div>
            <div class="attribute_contact_button">
                <a class="attribute_delete" @click="hideAttribute()">取消</a>
                <a @click="subProduct()">确定</a>
            </div>
        </div>
    </div>
</div>
<!-- 点击商品详情  选择属性弹出框end -->
  </div>
</template>
<script>
import Banner from '@/components/Banner'
let Base64 = require('js-base64').Base64
// import dateUtils from "@/assets/js/DateUtils";
export default {
  name: 'product_details',
  data () {
    return {
      saveData: {},
      listImg: [],
      request: {
        module: 'market',
        method: 'market.',
        request_mode: 'get',
        page: 1
      },
      reqRefereeRelation: {
        module: 'member',
        method: 'user.store_referee_relation',
        request_mode: 'post',
        uid: '',
        referee: ''
      },
      requestAdd: {
        module: 'order',
        method: 'cart',
        request_mode: 'post',
        buyer: '',
        seller: '',
        market_name: '',
        market_price: '',
        market_image: '',
        market_type: ''
      },
      market_id: '',
      market_number: 1,
      price: '',
      isShow: false,
      isPre: true,
      isNumber: false,
      clickBut: 1,
      refereeId: ''
    }
  },
  created () {
    this.saveData = this.$store.state.saveUData
    this.requestAdd.buyer = this.saveData.uid
    this.reqRefereeRelation.uid = this.saveData.uid
    let url = location.href.split('/')[4]
    this.request.method += url
    if (location.href.indexOf('referee') != -1) {
      let referee = location.href.split('?')[1].split('=')[1]
      //
      referee = Base64.decode(referee + '==')
      console.log(referee)
      this.reqRefereeRelation.referee = referee
      this.$getData({}, this.reqRefereeRelation).then(res => {
        if (res.status == 'success') {
          console.log(res)
        } else {
          console.log(res.msg)
        }
      })
    }
    if (this.$locache.get('userData')) {
      localStorage.removeItem('refereeUrl')
    }
    this.$getData({}, this.request).then(res => {
      console.log(res)
      if (res.status == 'success') {
        if (res.result.market_type != '2') {
          this.isPre = false
          this.requestAdd.market_price = res.result.presale_price
        } else {
          this.requestAdd.market_price = res.result.price
        }

        this.saveData = res.result
        this.listImg = res.result.market_many_image
        this.saveData.produce_date = res.result.produce_date.split(' ')[0]
        console.log(1111)
        this.market_id = res.result.id
        this.requestAdd.seller = res.result.shop_id
        // this.requestAdd.buyer = uInfo.uid;
        this.requestAdd.market_name = res.result.name

        this.requestAdd.market_image = res.result.image[0]
        this.requestAdd.market_type = res.result.market_type
        /// /console.log(this.requestAdd);
      } else {
        alert(res.msg)
      }
    })
  },
  computed: {
    ProPrice () {
      if (this.saveData != '') {
        if (this.saveData.market_type != '2') {
          return this.saveData.price
        } else {
          return this.saveData.presale_price
        }
      }
    },
    preEndDate () {
      let preEndDate = []
      if (this.saveData != '' && this.saveData.presale_end_time != null) { preEndDate = this.saveData.presale_end_time.split(' ')[0].split('-') }
      return preEndDate[0] + '年' + preEndDate[1] + '月' + (parseInt(preEndDate[2]) + 1) + '日'
    }
  },
  mounted () {},
  methods: {
    showContact () {
      this.isShow = true
    },
    hideContact () {
      this.isShow = false
    },
    showAttribute (val) {
      this.clickBut = val
      this.isNumber = true
    },
    hideAttribute () {
      this.market_number = '1'
      this.isNumber = false
    },
    AddNum () {
      this.market_number++
    },
    ReducNum () {
      if (this.market_number > 1) {
        this.market_number--
      }
    },
    subProduct () {
      // console.log("成功");
      if (this.saveData.number > 0) {
        if (this.clickBut == '1') {
          this.$getData(
            { market_number: this.market_number, market_id: this.market_id },
            this.requestAdd
          ).then(res => {
            // console.log(res);
            if (res.status == 'success') {
              this.isNumber = false
              this.$message({
                showClose: true,
                message: '添加成功',
                type: 'success'
              })
            }
          })
        } else {
          this.isNumber = false
          this.$store.state.saveMarketData = {
            market_number: this.market_number,
            market_id: this.market_id
          }
          this.$router.push({ path: '/order_generate_direct' })
        }
      } else {
        alert('库存不足')
      }
    },
    Direct () {
      this.isShow = true
    }
  },
  components: {
    'app-banner': Banner
  }
}
</script>
