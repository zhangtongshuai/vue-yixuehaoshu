<template>
  <div>
    <!-- 订单分类 -->

    <div class="order_nav" :style="marTop">
          <ul :style="marTop">
            <li v-for="(tab,idx) in tabsNavList" @click="tabsClick(idx)" :class="{active: idx==indexPrev}">{{tab.sort}}</li>
          </ul>
        </div>
    <!-- 订单分类 -->
  <transition name="slide">

    <div id="wrapper" ref="scrollWrap" :class="isSubscribe ? 'top58' : 'top0'">
      <div class="scroller" ref="scroller">
        <!-- 定单列表 -->
        <div class="order_list">
          <div class="order" v-for="(info,index) in saveData">
            <div class="order_top">
              <div class="title">
                <img :src="info.shop.avatar">
                <h1>{{info.shop.name}}</h1>
              </div>
              <span class="span1" v-if="info.status === -1">取消订单</span>
              <span v-else :class="info.status === 4 ? 'span2' : 'span1' ">{{OrderStatus[info.status]}}</span>
              <!-- <span class="span2">订单完成</span> -->
              <!-- 出去订单完成其余的状态都是span1 -->
            </div>
            <router-link v-for="bookItem in info.ordergoods" :to="{name:'order_details',params:info}" class="order_con">
              <div class="book">
                <div class="img"><img :src="bookItem.image"></div>
                <div class="title">
                  <h1>{{bookItem.market_name}}</h1>
                  <h2><span>￥{{bookItem.price}}</span><span>×{{bookItem.number}}</span></h2>
                </div>
              </div>
            </router-link>
            <div class="order_bot">
              <h1>共计{{proSum[index]}}件商品，合计<span>￥{{info.total}}</span></h1>
              <h1>（含运费：￥{{info.shipping_fee}}）</h1>
              <div class="button">
                <button v-if="info.status === 1" @click="CancelShow(index)">取消订单</button>
                <!-- <button @click="PopupShow(index)">取消订单</button> -->
                <button v-if="info.status === 1" class="confirm" @click="PayShow(index)">去支付</button>
                <button v-if="info.status === 3" class="confirm" @click="ConfirmShow(index)">确认收货</button>
                <button v-if="info.status === 2" @click="Reminder()">提醒发货</button>
              </div>
            </div>
          </div>
          <div class="no_more" v-if = "isWithout">
            <span></span>
            <p>咩有了~</p>
            <span></span>
          </div>
        </div>
        <!-- 订单列表 -->

      </div>
      <transition :name="loadingPosition">
            <Loading id="loading" v-show="showLoading" :class='{pullUpLoading}' ref="loading" :loadingWord="loadingWord"></Loading>
          </transition>
    </div>
  </transition>
    <!-- 确认订单弹窗 -->
    <div class="seller_contact2" v-show="isConfirm">
      <div class="seller_contact_con">
        <div class="seller_contact_con_con">
          <div class="seller_contact_top">
            <img src="@/assets/img/Popup.png">
            <a id="seller_contact_close" @click="ConfirmHide()">×</a>
          </div>
          <div class="seller_contact_bot">
            <p>请您确认收到货，否则可能钱货两空~</p>
          </div>
          <div class="seller_contact_button">
            <a @click="PayOrder()">确定</a>
            <a class="seller_delete" @click="ConfirmHide()">取消</a>
          </div>
        </div>
      </div>
    </div>
    <!-- 确认订单弹窗END -->
    <!-- 支付订单弹窗 -->
    <div class="seller_contact2" v-show="isPay">
      <div class="seller_contact_con">
        <div class="seller_contact_con_con">
          <div class="seller_contact_top">
            <img src="@/assets/img/Popup.png">
            <a id="seller_contact_close" @click="PayHide()">×</a>
          </div>
          <div class="seller_contact_bot">
            <p>支付~</p>
          </div>
          <div class="seller_contact_button">
            <a @click="PayOrder()">确定</a>
            <a class="seller_delete" @click="PayHide()">取消</a>
          </div>
        </div>
      </div>
    </div>
    <!-- 支付订单弹窗END -->
    <!-- 取消订单弹窗 -->
    <div class="seller_contact2" v-show="isCancel">
      <div class="seller_contact_con">
        <div class="seller_contact_con_con">
          <div class="seller_contact_top">
            <img src="@/assets/img/Popup.png">
            <a id="seller_contact_close" @click="CancelHide()">×</a>
          </div>
          <div class="seller_contact_bot">
            <p>取消~</p>
          </div>
          <div class="seller_contact_button">
            <a @click="CancelOrder()">确定</a>
            <a class="seller_delete" @click="CancelHide()">取消</a>
          </div>
        </div>
      </div>
    </div>
  <!-- 取消订单弹窗END -->
  <!-- <order-popup :data = "data" v-if="isPopup"></order-popup> -->
  </div>
</template>
<script>
import popup from '@/components/popup'
import BScroll from 'better-scroll'
import { getStyle, getDeviceRatio } from '@/assets/js/util.js'
import Loading from '@/components/loading.vue'
import locache from '@/assets/js/locache'
/* 获取当前缩放比 */
const DEVICE_RATIO = getDeviceRatio()

/**
 *
 * @param threshold 触发事件的阀值，即滑动多少距离触发
 * @param stop 下拉刷新后回滚
 */

/* 下拉配置 */
const DOWN_CONFIG = {
  threshold: 60 * DEVICE_RATIO,
  stop: 40 * DEVICE_RATIO
}
/* 上拉配置 */
const UP_CONFIG = {
  threshold: -60 * DEVICE_RATIO
}

export default {
  name: 'order',
  data () {
    return {
      activeName: 'second',
      tabPosition: 'top',
      userData:{},
      marTop: '',
      saveData: '',
      tabsNavList: [
        { sort: '全部', order_status: '' },
        { sort: '待付款', order_status: '1' },
        { sort: '待发货', order_status: '2' },
        { sort: '待收货', order_status: '3' },
        { sort: '已成交', order_status: '4' }
      ],
      reqGet: {
        method: 'order.get_all',
        page: '',
        user_type: '2',
        module: 'order',
        uid: '',
        status: '',
        request_mode: 'post'
      },
      reqConfirm: {
        method: 'order.confirm',
        order_id: '',
        module: 'order',
        uid: '',
        request_mode: 'post'
      },
      popupSort: '',
      CancelSort: '',
      reqStoreCharge: {
        request_mode: 'post',
        module: 'order',
        method: 'order.store_charge',
        uid: '',
        total: '',
        order_id: ''
      },
      reqCancel: {
        request_mode: 'post',
        module: 'order',
        method: 'order.cancel',
        uid: '',
        user_type: '2',
        order_id: ''
      },
      ConfirmOrderID: '',
      PayOrderIndex: '',
      isConfirm: false,
      isPay: false,
      isPopup: false,
      isCancel: false,
      indexPrev: 0,
      isWithout: false,
      OrderStatus: ['', '待付款', '待发货', '待收货', '订单完成'],
      uid: '',
      isAuthorized: true,
      scroller: null,
      center: true,
      pullUpLoading: false,
      showLoading: false,
      currentPage: 1,
      loadingWord: '正在加载',
      loadingPosition: '',
      noMoreData: false
    }
  },
  created () {
    this.userData = this.$locache.get('userData')
    console.log(this.userData.is_subscribe)
    if (this.isSubscribe) {
      this.marTop = { top: '52px', zIndex: '99'}
    }else{
      this.marTop = { top: '0', zIndex: '99'}
    }
    let state = this.$store.state
    this.uid = state.saveUData.uid
    this.isAuthorized = this.$store.state.isAuthorized
    this.reqGet.uid = this.userData.uid
    this.$getData({}, this.reqGet).then(res => {
      console.log(res)
      this.saveData = res.result
    })
  },
  mounted () {
    const { scroller, scrollWrap, scrollList } = this.$refs
    /* 初始化scroll */
    this.scroller = new BScroll(scrollWrap, {
      click: true,
      probeType: 2,
      pullUpLoad: UP_CONFIG
    })
    /* 下拉刷新 */
    this.scroller.on('pullingDown', () => this.pullDown())

    /* 上拉加载更多 */
    this.scroller.on('pullingUp', () => this.pullUp())
  },
  beforeCreate: function () {
    document.getElementsByTagName('body')[0].className = 'bg-fff'
  },
  computed: {
    proSum () {
      let proSum = []
      if (this.saveData != null) {
        this.saveData.forEach(i => {
          let proNum = 0
          i.ordergoods.forEach(j => {
            proNum += parseInt(j.number)
          })
          proSum.push(proNum)
        })
      }
      return proSum
    },
    isSubscribe () {
      return this.$store.getters.isSubscribe
    }
  },
  methods: {
    tabsClick (tabIndex) {
      this.indexPrev = tabIndex
      // console.log(tabIndex);
      this.reqGet.status = parseInt(this.tabsNavList[tabIndex].order_status)
      // console.log(this.reqGet);
      this.$getData({}, this.reqGet).then(response => {
        // console.log(response);
        this.saveData = response.result
      })
    },
    Reminder () {
      this.$message('提醒成功')
    },
    ConfirmShow (index) {
      this.ConfirmOrderID = index
      this.isConfirm = true
    },
    PayShow (index) {
      this.PayOrderIndex = index
      this.isPay = true
    },
    PopupShow (index) {
      this.popupSort = index
      this.isPopup = true
    },
    CancelShow (index) {
      this.CancelSort = index
      this.isCancel = true
    },
    CancelHide () {
      this.isCancel = false
    },
    ConfirmHide () {
      this.isCancel = false
    },

    PayHide () {
      this.isPay = false
    },
    ConfirmOrder () {
      this.reqConfirm.uid = this.uid
      this.reqConfirm.order_id = this.saveData[this.ConfirmOrderID].id
      // console.log(this.reqConfirm.order_id);
      this.$getData({}, this.reqConfirm).then(res => {
        // console.log(res);
        if (res.result == 1) {
          this.isConfirm = false
          this.saveData.splice(this.ConfirmOrderID, 1)
        }
        // this.saveData = res.result;
      })
    },
    CancelOrder () {
      this.isCancel = false
      this.reqCancel.uid = this.uid
      this.reqCancel.order_id = this.saveData[this.CancelSort].id
      // console.log(this.reqCancel);
      this.$getData({}, this.reqCancel).then(res => {
        // console.log(res);
        this.saveData.splice(this.CancelSort, 1)
      })
    },
    PayOrder () {
      // console.log("成功");
      let state = this.$store.state
      let openid = state.saveUData.openid
      this.reqStoreCharge.uid = this.uid
      this.reqStoreCharge.order_id = this.saveData[this.PayOrderIndex].id
      this.reqStoreCharge.total = this.saveData[this.PayOrderIndex].total
      this.$getData({}, this.reqStoreCharge).then(res => {
        this.pay = res.result
        console.log(this.pay);
        this.getPay(openid)
      })
    },
    getPay (openid) {
      if (this.isAuthorized) {
        this.$http
          .get(
            'http://librarypay.zhongmeiyixue.com/wechat/mp?out_trade_no=' +
            this.pay.charge_no +
            '&body=1111&total_fee=' +
            parseFloat(this.pay.amount) * 100 +
            '&openid=' +
            openid
          )
          .then(respon => {
            // console.log(respon.data);
            this.isPay = false
            this.callpay(respon.data)
          })
      } else {
        window.location.href =
          'http://librarypay.zhongmeiyixue.com/alipay/wap?out_trade_no=' +
          this.pay.charge_no +
          '&total_amount=' +
          Math.round(parseFloat(this.pay.amount) * 100) +
          '&subject=企业图书馆支付订单'
      }
    },
    jsApiCall (result) {
      // console.log;
      let _this = this
      WeixinJSBridge.invoke('getBrandWCPayRequest', result, function (res) {
        // alert(res.err_msg)
        if (res.err_msg == 'get_brand_wcpay_request:ok') {
          _this.$message('支付成功')
          _this.$router.push({ path: '/order' })
        } else {
          _this.$message('支付失败')
        }
      })
    },
    callpay (res) {
      /// /console.log(res)
      if (typeof WeixinJSBridge === 'undefined') {
        if (document.addEventListener) {
          document.addEventListener('WeixinJSBridgeReady', jsApiCall, false)
        } else if (document.attachEvent) {
          document.attachEvent('WeixinJSBridgeReady', jsApiCall)
          document.attachEvent('onWeixinJSBridgeReady', jsApiCall)
        }
      } else {
        this.jsApiCall(res)
      }
    },
    // 滚动方法
    pullUp () {
      this.currentPage++
      this.reqGet.page = this.currentPage
      console.log(this.currentPage)
      if (!this.noMoreData) {
        this.beforeFetch('Up')
        setTimeout(() => {
          this.$getData({}, this.reqGet).then(res => {
            console.log(res)
            if (res.result.length > 0) {
              this.saveData = this.saveData.concat(res.result)
            } else {
              this.isWithout = true
              this.noMoreData = true
            }
            this.afterFetch('Up')
          })
            .catch((error) => {
              this.afterFetch('Up')
            })
        }, 1000)
      }
    },
    enable () {
      this.scroller && this.scroller.enable()
    },
    disable (type) {
      this.scroller && this.scroller.disable()
    },
    finishPullUp () {
      this.scroller && this.scroller.finishPullUp()
    },
    refresh () {
      this.scroller && this.scroller.refresh()
    },
    beforeFetch (type) {
      this[`pull${type}Loading`] = true
      this[`inPulling${type}`] = true
      this.showLoading = true
      if (type == 'Up') {
        this.loadingPosition = 'bot'
        this.loadingWord = '正在加载更多'
      }
    },
    afterFetch (type) {
      this.enable()
      this['finishPull' + type]()
      this.showLoading = false
      setTimeout(() => {
        this[`pull${type}Loading`] = false
      }, 300)
    }
  },
  watch: {
    data () {
      this.$nextTick(() => {
        this.scroller.refresh()
      })
    }
  },
  components: {
    'order-popup': popup,
    Loading
  }
}

</script>
