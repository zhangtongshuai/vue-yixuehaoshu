<template>
<div>
        <!-- 地址信息 -->
    <div class="order_address">
        <div class="order_address_con">
            <div class="order_bg1"></div>
            <div class="order_bg2"></div>
            <div class="order_address_top">
                <router-link v-if="isAddShow"  to="/address">
                    <div class="link">
                        <div>
                            <i class="iconfont">&#xe65b;</i>
                            <span>收货人：</span>
                        </div>
                        <p>{{saveAddress.consignee}}（{{saveAddress.mobile}}）</p>
                    </div>
                    <div class="link">
                        <div>
                            <i class="iconfont">&#xe63e;</i>
                            <span>收货地址：</span>
                        </div>
                        <p>{{saveAddress.province}}{{saveAddress.city}}{{saveAddress.district}}{{saveAddress.address}}</p>
                    </div>
                </router-link>
                <router-link  v-else to="/add_address" class="wu_address">
                    <i class="iconfont">&#xe63e;</i>
                    <p>请先添加收货地址~</p>
                </router-link>
                <router-link class="right" to="/address">
                    <img src="@/assets/img/xia.png">
                </router-link>
            </div>
            <div class="order_bg3"></div>
            <div class="order_bg1"></div>
        </div>
    </div>
    <!-- 地址信息结束 -->

    <!-- 订单信息 -->
    <div class="order_info">
        <div class="order">
            <div class="order_top">
                <div class="title">
                    <img :src="saveData.shop_avatar">
                    <h1>{{saveData.shop_name}}</h1>
                </div>
            <a class="contact_seller" @click="showContact">联系卖家</a>
            </div>
            <a class="order_con">
                <div class="book">
                    <div class="img"><img :src="saveData.market_image"></div>
                    <div class="title">
                        <h1>{{saveData.market_name}}</h1>
                        <h2>
                            <span v-if="saveData.market_type == 1">￥{{saveData.market_price}}</span>
                            <span v-else>￥{{saveData.market_presale_price}}</span>
                            <span>×{{saveData.market_number}}</span></h2>
                    </div>
                </div>
            </a>
            <div class="tjr">
                <span>推荐人</span>
                <!-- <select>
                    <option value="1">杨洋</option>
                </select> -->
                <span v-if="saveData.referee != null">{{saveData.referee.name}}{{saveData.referee.mobile}}</span>
            </div>
            <div class="liuyan">
                <textarea rows="1" placeholder="请输入您的小要求~" v-model="NoteText"></textarea>
            </div>
            <div class="order_bot">

                <h1>共计{{saveData.market_number}}件商品，合计<span>￥{{sum}}</span></h1>

                <h1>（含运费：￥{{fee}}）</h1>
            </div>
        </div>

        <div class="order_tips">*支付前请先与对方确认交易细节！</div>
    </div>
    <!-- 订单信息end -->
    <!-- 支付 -->
    <div class="order_pay">
        <div class="pay_top">

            <h2>共计{{saveData.market_number}}件商品，运费￥{{fee}}</h2>
            <h1>￥<font>{{sum}}</font></h1>
        </div>
        <div class="pay_bot">
            <span @click="back()">回首页</span>
            <span type="primary" @click="openFullScreen" v-loading.fullscreen.lock="fullscreenLoading">
                支付
            </span>
        </div>
    </div>
    <!-- 支付end -->
      <!-- 联系供货商点击弹出框 -->
<div class="seller_contact" v-if="isShow">
    <div class="seller_contact_con">
        <div class="seller_contact_con_con">
            <div class="seller_contact_top">
                <img src="@/assets/img/Popup.png">
                <a id="seller_contact_close" @click="hideContact()">×</a>
            </div>
            <div class="seller_contact_bot">
                <div class="seller_contact_ewm">
                    <img :src="saveData.shop_qrcode">
                </div>
                <a :href="':tel' + saveData.shop_mobile" v-show="saveData.shop_mobile !=0">电话：{{saveData.shop_mobile}} <button>拨打</button></a>
                <a v-show="saveData.shop_brief != ''">公告：{{saveData.shop_brief}}</a>
                <a>地址：{{saveData.shop_province}}{{saveData.shop_city}}{{saveData.shop_address}}</a>
            </div>
        </div>
    </div>
</div>
<!-- 联系供货商点击弹出框end -->
</div>
</template>
<script>
export default {
  name: 'order_generate_direct',
  data () {
    return {
      saveAddress: '',
      saveData: '',
      uid: '',
      reqAddress: {
        // 获取地址参数
        request_mode: 'post',
        module: 'member',
        method: 'address.show_default'
      },
      reqDirect: {
        //
        module: 'order',
        method: 'order.order_page',
        request_mode: 'post'
      },
      reqDirectOrder: {
        module: 'order',
        method: 'order.order',
        request_mode: 'post'
      },
      reqStoreCharge: {
        request_mode: 'post',
        module: 'order',
        method: 'order.store_charge',
        uid: '',
        total: '',
        order_id: ''
      },
      uid: '',
      isAddShow: false,
      pay: {},
      isShow: false,
      NoteText: '',
      market_id: '',
      market_number: '',
      fullscreenLoading: false,
      isAuthorized: true
    }
  },
  created () {
    let state = this.$store.state
    this.uid = state.saveUData.uid
    // console.log(state.address);
    this.saveAddress = state.address
    this.market_id = state.saveMarketData.market_id
    this.market_number = state.saveMarketData.market_number
    this.isAuthorized = state.isAuthorized
  },
  mounted () {
    let state = this.$store.state
    if (state.address.length != 0) {
      // 判断是否保是自己选中的地址
      this.saveAddress = state.address
      // console.log( this.saveAddress);
      let address_id = state.address.id
      this.$getData(
        {
          uid: this.uid,
          market_id: this.market_id,
          market_number: this.market_number,
          address_id: address_id
        },
        this.reqDirect
      ).then(res => {
        // 获取订单详情
        console.log(res)
        this.saveData = res.result
        if (res.result != null) {
          this.isAddShow = true
        }
      })
    } else {
      this.$getData({ uid: this.uid }, this.reqAddress).then(res => {
        // 获取地址
        /// /console.log(res)
        let address_id = ''
        if (res.result != null) {
          this.isAddShow = true
          state.address = res.result
          this.saveAddress = state.address
          address_id = state.address.id
        } else {
          this.isAddShow = false
          address_id = 0
        }
        this.$getData(
          {
            uid: this.uid,
            market_id: this.market_id,
            market_number: this.market_number,
            address_id: address_id
          },
          this.reqDirect
        ).then(res => {
          // 获取订单详情
          // console.log(res);
          this.saveData = res.result
        })
      })
    }
  },
  computed: {
    sum () {
      let sum = []
      if (this.saveData != '') {
        if (this.saveData.total > this.saveData.fee.max_fee) {
          sum = parseFloat(this.saveData.total)
        } else {
          sum = (
            parseFloat(this.saveData.total) +
            parseFloat(this.saveData.fee.base_fee)
          ).toFixed(2)
        }
      }

      return sum
    },
    fee () {
      let fee = []
      if (this.saveData != '') {
        if (this.saveData.total > this.saveData.fee.max_fee) {
          fee = '0.00'
        } else {
          fee = this.saveData.fee.base_fee
        }
      }

      return fee
    }
  },
  methods: {
    showContact () {
      this.isShow = true
    },
    hideContact () {
      this.isShow = false
    },
    back () {
      this.$router.push({ path: '/' })
    },
    openFullScreen () {
      this.fullscreenLoading = true
      console.log('saveAddress',this.saveAddress)
      if (this.saveAddress.length == 0) {
        this.fullscreenLoading = false
        this.$message.error('请先输入收货地址')
      } else {
        setTimeout(() => {
          this.fullscreenLoading = false
        }, 1500)
        this.subOrder()
      }
    },

    subOrder () {
      // console.log("成功");
      let state = this.$store.state
      let address_id = state.address.id
      let openid = state.saveUData.openid
      /// /console.log(openid);
      // console.log(JSON.stringify(this.pay));
      if (JSON.stringify(this.pay) == '{}') {
        this.$getData(
          {
            uid: this.uid,
            market_id: this.market_id,
            market_number: this.market_number,
            address_id: address_id,
            remark: this.NoteText
          },
          this.reqDirectOrder
        ).then(res => {
          this.reqStoreCharge.uid = this.uid
          this.reqStoreCharge.order_id = res.result.order_id
          this.reqStoreCharge.total = res.result.total
          this.$getData({}, this.reqStoreCharge).then(res => {
            this.pay = res.result
            console.log(this.pay);
            this.getPay(openid)
          })
        })
      } else {
        this.getPay(openid)
      }
    },
    getPay (openid) {
      // alert(this.isAuthorized);
      if (this.isAuthorized) {
        this.$http
          .get(
            'http://librarypay.zhongmeiyixue.com/wechat/mp?out_trade_no=' +
              this.pay.charge_no +
              '&body=企业图书馆支付订单&total_fee=' +
              Math.round(parseFloat(this.pay.amount) * 100) +
              '&openid=' +
              openid
          )
          .then(respon => {
            console.log(respon.data)
            this.callpay(respon.data)
          })
      } else {
        window.location.href = 'http://librarypay.zhongmeiyixue.com/alipay/wap?out_trade_no=' +
        this.pay.charge_no + '&total_amount=' +
        Math.round(parseFloat(this.pay.amount) * 100) + '&subject=企业图书馆支付订单'
      }
    },
    jsApiCall (result) {
      // console.log;
      let _this = this
      WeixinJSBridge.invoke('getBrandWCPayRequest', result, function (res) {
        // alert(res.err_msg)
        if (res.err_msg == 'get_brand_wcpay_request:ok') {
          _this.$message('支付成功')
          _this.$router.push({ path: '/order' })
        } else {
          _this.$message('支付失败')
        }
      })
    },
    callpay (res) {
      /// /console.log(res)
      if (typeof WeixinJSBridge === 'undefined') {
        if (document.addEventListener) {
          document.addEventListener('WeixinJSBridgeReady', jsApiCall, false)
        } else if (document.attachEvent) {
          document.attachEvent('WeixinJSBridgeReady', jsApiCall)
          document.attachEvent('onWeixinJSBridgeReady', jsApiCall)
        }
      } else {
        this.jsApiCall(res)
      }
    }
    // onBridgeReady(resData) {
    //   WeixinJSBridge.invoke("getBrandWCPayRequest", resData, function(res) {
    //     if (res.err_msg == "get_brand_wcpay_request:ok") {
    //     } // 使用以上方式判断前端返回,微信团队郑重提示：res.err_msg将在用户支付成功后返回    ok，但并不保证它绝对可靠。
    //   });
    // }
  }
}
// function onBridgeReady() {
//   WeixinJSBridge.invoke(
//     "getBrandWCPayRequest",
//     {"appId":"wxecbdd99e6e605612","timeStamp":"1524730724","nonceStr":"XXPTYoe36lZ0Pp75","package":"prepay_id=wx261618450659972a1d9ff1c40097012452","signType":"MD5","paySign":"8FE81501CFFF0232CEF2DC4EDB890414"},
//     function(res) {
//       if (res.err_msg == "get_brand_wcpay_request:ok") {
//       } // 使用以上方式判断前端返回,微信团队郑重提示：res.err_msg将在用户支付成功后返回    ok，但并不保证它绝对可靠。
//     }
//   );
// }
// if (typeof WeixinJSBridge == "undefined") {
//   if (document.addEventListener) {
//     document.addEventListener("WeixinJSBridgeReady", onBridgeReady, false);
//   } else if (document.attachEvent) {
//     document.attachEvent("WeixinJSBridgeReady", onBridgeReady);
//     document.attachEvent("onWeixinJSBridgeReady", onBridgeReady);
//   }
// } else {
//   onBridgeReady();
// }
</script>
<style>

</style>
