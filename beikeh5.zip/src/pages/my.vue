<template>
  <div>
    <!-- 个人中心 -->
<div class="mine">
    <div class="mine_top">
        <div class="basic">
            <div class="photo">
                <img :src="saveDate.avatar" class="head_photo">

                <span>
                    <!-- 女 -->
                    <img v-if = 'saveDate.sex == 2' src="@/assets/img/woman.png">
                    <!-- 男 -->
                    <img v-if = 'saveDate.sex == 1' src="@/assets/img/man.png"></span>
            </div>
            <div class="title">
                <h1>{{saveDate.name}}</h1>
                <h1>ID：{{saveDate.user_id}}</h1>
            </div>
        </div>
    </div>
    <div class="mine_bot">
        <router-link to="/address">
            <div class="mine_left">
                <i class="iconfont">&#xe63e;</i>
                <span>收货地址</span>
            </div>
            <div class="mine_right">
                <img src="@/assets/img/xia.png">
            </div>
        </router-link>
        <a >
            <div class="mine_left">
                <i class="iconfont">&#xe654;</i>
                <span @click = "setShow()">设置</span>
            </div>
            <div class="mine_right">
                <img src="@/assets/img/xia.png">
            </div>
        </a>
        <h1>客服电话：400-651-7851</h1>
    </div>
</div>
<!-- 个人中心end -->
  <div class="seller_contact2" v-show="isSet">
          <div class="seller_contact_con">
            <div class="seller_contact_con_con">
              <div class="seller_contact_top">
                <img src="@/assets/img/Popup.png">
                <a id="seller_contact_close" @click="setHide()">×</a>
              </div>
              <div class="seller_contact_bot">
                <p>该功能暂未开放</p>
              </div>
              <div class="seller_contact_button">
                <a @click="setHide()">确定</a>
              </div>
            </div>
          </div>
        </div>
  </div>
</template>

<script>
import customMethods from '@/assets/js/customMethods'
import locache from '@/assets/js/locache'
export default {
  name: 'my',
  data () {
    return {
      msg: 'This is my',
      request: {
        module: 'member',
        method: 'user.show',
        request_mode: 'post'
      },
      uid: '',
      isSet: false,
      saveDate: ''
    }
  },
  beforeCreate: function () {
    document.getElementsByTagName('body')[0].className = 'bg-fff'
  },
  mounted () {
    let state = this.$store.state
    let saveUData = state.saveUData
    let UData = locache.get('userData')
    console.log(UData)
    if (UData == null) {
      this.uid = saveUData.uid
    } else {
      this.uid = UData.uid
    }
    this.$getData({ uid: this.uid }, this.request).then(res => {
      console.log(res)
      this.saveDate = res.result
    })
  },
  methods: {
    setShow () {
      this.isSet = true
    },
    setHide () {
      this.isSet = false
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
