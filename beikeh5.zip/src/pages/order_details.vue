<template>
  <div>
    <!-- 订单状态 -->
    <div class="order_state">
      <div class="order_state_left">
        <h1>{{orderStatusList[saveData.status].sort}}</h1>
        <h2 v-if="saveData.status ===3">还剩{{confirmtime}}自动确认</h2>
      </div>
      <div class="order_state_right">
        <img src="@/assets/img/mascot.png">
      </div>
    </div>
    <!-- 订单状态end -->
    <!-- 地址信息 -->
    <div class="order_details_address">
      <div class="order_address_con">
        <div class="order_bg1"></div>
        <div class="order_bg2"></div>
        <div class="order_address_top">
          <div class="link">
            <div>
              <i class="iconfont">&#xe65b;</i>
              <span>收货人：</span>
            </div>
            <p>{{saveData.consignee}}（{{saveData.mobile}}）</p>
          </div>
          <div class="link">
            <div>
              <i class="iconfont">&#xe63e;</i>
              <span>收货地址：</span>
            </div>
            <p>{{saveData.province}}{{saveData.city}}{{saveData.district}}{{saveData.address}}</p>
          </div>
        </div>
        <div class="order_address_bot" v-if="saveData.status ===3 || saveData.status ===4">
          <h1>快递单号:<p id="link">{{express_no}}</p></h1>
          <div class="caozuo">
            <a href="#">再次购买</a>
            <el-button id="copyBtn" v-clipboard:copy="express_no" v-clipboard:success="onCopy" v-clipboard:error="onError">
              复制单号</el-button>
            <!--复制问题解决参考： https://www.cnblogs.com/pujianguo/p/5300134.html -->
          </div>
        </div>
        <div class="order_bg3"></div>
        <div class="order_bg1"></div>
      </div>
    </div>
    <!-- 地址信息结束 -->
    <!-- 订单信息 -->
    <div class="order_details">
      <div class="order">
        <div class="order_top">
          <div class="title">
            <img :src="saveData.shop.avatar">
            <h1>{{saveData.shop.name}}</h1>
          </div>
          <span :class="saveData.status === 4 ? 'span2' : 'span1' ">{{OrderStatus[saveData.status]}}</span>
          <!-- <span class="span2">订单完成</span> -->
          <!-- 出去订单完成其余的状态都是span1 -->
        </div>
        <a class="order_con">
          <div class="book" v-for="info in saveData.ordergoods">
            <div class="img"><img :src="info.image"></div>
            <div class="title">
              <h1>{{info.market_name}}</h1>
              <h2><span>￥{{info.price}}</span><span>×{{info.number}}</span><button>加购物车</button></h2>
            </div>
          </div>
        </a>
        <div class="tjr">
          <span>推荐人</span>
          <h1 v-if="saveData.referee_info != null">{{saveData.referee_info.name}}</h1>
        </div>
        <div class="liuyan" v-if="saveData.remark != ''">
          <span>{{saveData.remark}}</span>
        </div>
        <div class="order_bot">
          <h1>共计2件商品，合计<span>￥{{saveData.total}}</span></h1>
          <h1>（含运费：￥{{saveData.shipping_fee}}）</h1>
        </div>
      </div>
      <div class="order">
        <h2>订单信息</h2>
        <div class="order_infor">
          <span>订单编号</span>
          <p>{{saveData.order_no}}</p>
        </div>
        <div class="order_infor">
          <span>创建时间</span>
          <p>{{saveData.created_at}}</p>
        </div>
        <div class="order_infor" v-if="saveData.pay_time != null">
          <span>支付时间</span>
          <p>{{saveData.pay_time}}</p>
        </div>
        <div class="order_infor" v-if="saveData.deliver_time != null">
          <span>发货时间</span>
          <p>{{saveData.deliver_time}}</p>
        </div>
        <div class="order_infor" v-if="saveData.confirm_time != null">
          <span>完成时间</span>
          <p>{{saveData.confirm_time}}</p>
        </div>
      </div>
    </div>
    <!-- 订单信息end -->
    <!-- 联系供货商点击弹出框 -->
    <div class="seller_contact" v-if="isShow">
      <div class="seller_contact_con">
        <div class="seller_contact_con_con">
          <div class="seller_contact_top">
            <img src="@/assets/img/Popup.png">
            <a id="seller_contact_close" @click="ContactHide()">×</a>
          </div>
          <div class="seller_contact_bot">
            <div class="seller_contact_ewm">
              <img :src="saveData.shop.qrcode">
            </div>
            <a :href="'tel:' + saveData.shop.mobile" v-show="saveData.shop.mobile !=0">电话：{{saveData.shop.mobile}} <button>拨打</button></a>
            <a v-show="saveData.shop.brief != ''">公告：{{saveData.shop.brief}}</a>
            <a>地址：{{saveData.shop.province_name}}{{saveData.shop.city_name}}{{saveData.shop.address}}</a>
          </div>
        </div>
      </div>
    </div>
    <!-- 联系供货商点击弹出框end -->
    <!-- 支付 -->
    <div class="order_pay">
      <div class="pay_bot cancel_order_box" v-if="saveData.status ===1">
        <span class="contact_seller cancel_order" @click="CancelShow()">取消订单</span>
        <span class="contact_seller" @click="ContactShow()">联系卖家</span>
        <span @click="PayShow()">支付</span>
      </div>
      <div class="pay_bot" v-else>
        <span class="contact_seller" @click="ContactShow()">联系卖家</span>
        <span @click="ConfirmShow()" v-if="saveData.status ===3">确认收货</span>
        <span class = "cancel_order_box" v-if="saveData.status ===4">已收货</span>
        <span  v-if="saveData.status ===2" >确认收货</span>
      </div>
    </div>
    <!-- 支付end -->
    <!-- 确认订单弹窗 -->
  <div class="seller_contact2" v-show="isConfirm">
    <div class="seller_contact_con">
        <div class="seller_contact_con_con">
            <div class="seller_contact_top">
                <img src="@/assets/img/Popup.png">
                <a id="seller_contact_close"  @click="ConfirmHide()">×</a>
            </div>
            <div class="seller_contact_bot">
                <p>请您确认收到货，否则可能钱货两空~</p>
            </div>
            <div class="seller_contact_button">
                <a @click="ConfirmOrder()">确定</a>
                <a class="seller_delete" @click="ConfirmHide()">取消</a>
            </div>
        </div>
    </div>
</div>
  <!-- 确认订单弹窗END -->
  <!-- 支付订单弹窗 -->
  <div class="seller_contact2" v-show="isPay">
    <div class="seller_contact_con">
        <div class="seller_contact_con_con">
            <div class="seller_contact_top">
                <img src="@/assets/img/Popup.png">
                <a id="seller_contact_close"  @click="PayHide()">×</a>
            </div>
            <div class="seller_contact_bot">
                <p>支付~</p>
            </div>
            <div class="seller_contact_button">
                <a @click="PayOrder()">确定</a>
                <a class="seller_delete" @click="PayHide()">取消</a>
            </div>
        </div>
    </div>
</div>
  <!-- 支付订单弹窗END -->
   <!-- 取消订单弹窗 -->
  <div class="seller_contact2" v-show="isCancel">
    <div class="seller_contact_con">
        <div class="seller_contact_con_con">
            <div class="seller_contact_top">
                <img src="@/assets/img/Popup.png">
                <a id="seller_contact_close"  @click="CancelHide()">×</a>
            </div>
            <div class="seller_contact_bot">
                <p>取消~</p>
            </div>
            <div class="seller_contact_button">
                <a @click="CancelOrder()">确定</a>
                <a class="seller_delete" @click="CancelHide()">取消</a>
            </div>
        </div>
    </div>
</div>
  <!-- 取消订单弹窗END -->
  </div>
</template>
<script>
export default {
  name: "order_details",
  data() {
    return {
      reqDetail: {
        method: "order.detail",
        user_type: "2",
        module: "order",
        uid: "",
        request_mode: "post"
      },
      reqConfirm: {
        method: "order.confirm",
        order_id: "",
        module: "order",
        uid: "",
        request_mode: "post"
      },
      reqStoreCharge: {
        request_mode: "post",
        module: "order",
        method: "order.store_charge",
        uid: "",
        total: "",
        order_id: ""
      },
      reqCancel: {
        request_mode: "post",
        module: "order",
        method: "order.cancel",
        uid: "",
        user_type: "2",
        order_id: ""
      },
      saveData: "",
      isShow: false,
      orderStatusList: [
        { sort: "", order_status: "" },
        { sort: "未付款", order_status: "1" },
        { sort: "用户已付款，等待发货", order_status: "2" },
        { sort: "待收货", order_status: "3" },
        { sort: "订单完成", order_status: "4" }
      ],
      OrderStatus: ["", "待付款", "待发货", "待收货", "订单完成"],
      requestAdd: {
        module: "order",
        method: "cart",
        request_mode: "post",
        buyer: "",
        seller: "",
        market_name: "",
        market_price: "",
        market_image: "",
        market_type: ""
      },
      isConfirm: false,
      isPay: false,
      isPopup: false,
      isCancel: false,
      isAuthorized: true,
      indexPrev: 0,
    };
  },
  mounted() {
    let state = this.$store.state;
    this.reqDetail.uid = state.saveUData.uid;
    this.isAuthorized = state.isAuthorized;
    let order_id = this.$route.params.id;
    this.$getData({ order_id: order_id }, this.reqDetail).then(res => {
      console.log(res.result);
      this.saveData = res.result;

    });
  },
  computed: {
    express_no() {
      let express_no = "";
      if (this.saveData.express_no != null) {
        express_no = this.saveData.express_no;
      } else {
        express_no = "暂无";
      }
      return express_no;
    },
    confirmtime() {
      let confirmtime = "";
      let date = new Date();
      if (this.saveData.status === 3) {
        //this.saveData.deliver_time.
        date = Date.parse(this.saveData.created_at) + 24 * 60 * 60 * 1000 * 15 - date.getTime();
        confirmtime = parseInt(date / (24 * 60 * 60 * 1000)) + '天' + parseInt(date % (24 * 60 * 60 * 1000) / (60 * 60 * 1000)) + '小时'
      }
      return confirmtime;
    }
  },
  methods: {
    OrderConfirm() {
      this.$message("确认收货");
      //console.log();
    },
    ContactShow() {
      this.isShow = true;
    },
    ContactHide() {
      this.isShow = false;
    },
    // 复制成功
    onCopy(e) {
      //console.log(e);
    },
    // 复制失败
    onError(e) {
      alert("失败");
    },
    addShop() {
      if (this.saveData != null)
      this.requestAdd.seller = this.saveData.seller;
      this.requestAdd.market_name = this.saveData.name;
      this.requestAdd.market_price = this.saveData.price;
      this.requestAdd.market_image = this.saveData.image[0];
      this.requestAdd.market_type = this.saveData.market_type;
      this.$getData({ market_number: this.market_number, market_id: this.market_id }, this.requestAdd).then(res => {
        //console.log(res);
        if (res.status == "success") {
          this.isNumber = false;
          this.$message({
            showClose: true,
            message: "添加成功",
            type: "success"
          });
        }
      });
    },
    ConfirmShow(index) {
        // 确认订单弹窗
      this.ConfirmOrderID = index;
      this.isConfirm = true;
    },
    PayShow(index) {
        // 支付订单弹窗
      this.PayOrderIndex = index;
      this.isPay = true;
    },
    CancelShow(index) {
        // 取消订单弹窗
      this.CancelSort = index;
      this.isCancel = true;
    },
    CancelHide() {
        // 取消订单弹窗

      this.isCancel = false;
    },
    ConfirmHide() {
        // 取消订单弹窗
      this.isConfirm = false;
    },

    PayHide() {
        // 支付订单弹窗

      this.isPay = false;
    },
    ConfirmOrder() {
      //确认收货
      this.reqConfirm.uid = this.saveData.buyer;
      this.reqConfirm.order_id = this.saveData.id;
      console.log(this.reqConfirm.uid);
      this.$getData({}, this.reqConfirm).then(res => {
        //console.log(res);
        if (res.result == 1) {
          this.isConfirm = false;
          this.$router.push({ path: "/order" })
        }
        //this.saveData = res.result;
      });
    },
    CancelOrder() {
      this.isCancel = false;
      this.reqCancel.uid = this.saveData.buyer;
      this.reqCancel.order_id = this.saveData.id;
      //console.log(this.reqCancel);
      this.$getData({}, this.reqCancel).then(res => {
        //console.log(res);
        this.$router.push({ path: "/order" })
      });
    },
    PayOrder() {
      //console.log("成功");
      let state = this.$store.state;
      let openid = state.saveUData.openid;
      this.reqStoreCharge.uid = this.saveData.buyer;
      this.reqStoreCharge.order_id = this.saveData.id;
      this.reqStoreCharge.total = this.saveData.total;
      this.$getData({}, this.reqStoreCharge).then(res => {
        this.pay = res.result;
        //console.log(this.pay);
        this.getPay(openid);
      });
    },
    getPay(openid) {
      if (this.isAuthorized) {
        this.$http
          .get(
            "http://librarypay.zhongmeiyixue.com/wechat/mp?out_trade_no=" +
              this.pay.charge_no +
              "&body=1111&total_fee=" +
              parseFloat(this.pay.amount) * 100 +
              "&openid=" +
              openid
          )
          .then(respon => {
            //console.log(respon.data);
            this.isPay = false;
            this.callpay(respon.data);
          });
      } else {
        window.location.href =
          "http://librarypay.zhongmeiyixue.com/alipay/wap?out_trade_no=" +
          this.pay.charge_no +
          "&total_amount=" +
          Math.round(parseFloat(this.pay.amount) * 100) +
          "&subject=企业图书馆支付订单";
      }
    },
    jsApiCall(result) {
      //console.log;
      let _this = this;
      WeixinJSBridge.invoke("getBrandWCPayRequest", result, function(res) {
        //alert(res.err_msg)
        if (res.err_msg == "get_brand_wcpay_request:ok") {
          _this.$message("支付成功");
          _this.$router.push({ path: "/order" });
        } else {
          _this.$message("支付失败");
        }
      });
    },
    callpay(res) {
      ////console.log(res)
      if (typeof WeixinJSBridge == "undefined") {
        if (document.addEventListener) {
          document.addEventListener("WeixinJSBridgeReady", jsApiCall, false);
        } else if (document.attachEvent) {
          document.attachEvent("WeixinJSBridgeReady", jsApiCall);
          document.attachEvent("onWeixinJSBridgeReady", jsApiCall);
        }
      } else {
        this.jsApiCall(res);
      }
    }
  }
};

</script>
