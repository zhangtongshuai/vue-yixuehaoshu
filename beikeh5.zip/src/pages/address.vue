<template>
  <!-- 地址 -->
<div class="address">
    <router-link :to="{name:'add_address',query:urlRouterquery}" class="add_address">
        <div class="add_address_left">
            <i class="iconfont">&#xe63e;</i>
            <span>增加收货地址</span>
        </div>
        <div class="add_address_right">
            <img src="@/assets/img/xia.png">
        </div>
    </router-link>
    <div class="address_list" v-for="(item,index) in saveData" >
        <div class="list_top">
            <span>{{item.consignee}}</span>
            <span>{{item.mobile}}</span>
        </div>
        <div class="list_con" @click="updateAddress(index)">
            {{item.province}} {{item.city}} {{item.district}} {{item.address}}
        </div>
        <div class="list_bot">
            <div class="list_bot_left">

                <label :for="index"><input type="checkbox" v-model="is_default[index]" :id="index">
                    <span @click="setDefault(index)"></span>
                </label>
                <h2>设为默认地址</h2>
            </div>
            <div class="list_bot_right">
                <button @click="delShow(index)">删除</button>
                <button @click="updateAdd(index)">编辑</button>
            </div>
        </div>
    </div>

<div class="seller_contact2" v-show="isDel">
    <div class="seller_contact_con">
        <div class="seller_contact_con_con">
            <div class="seller_contact_top">
                <img src="@/assets/img/Popup.png">
                <a id="seller_contact_close"  @click="delHide()">×</a>
            </div>
            <div class="seller_contact_bot">
                <p>真的要删除这个地址吗？</p>
            </div>
            <div class="seller_contact_button">
                <a @click="delAdd()">是真的要删</a>
                <a class="seller_delete" @click="delHide()">算了不删了</a>
            </div>
        </div>
    </div>
</div>

</div>
<!-- 地址结束 -->
</template>
<script>
export default {
  data () {
    return {
      saveData: [],
      reqAddress: {
        module: 'member',
        method: 'address.get_all',
        request_mode: 'post'
      },
      isDel: false,
      delIndex: 0,
      reqDelete: {
        module: 'member',
        method: 'address.delete',
        request_mode: 'post'
      },
      reqUpdate: {
        module: 'member',
        method: 'address.set_default',
        request_mode: 'post'
      },
      uid: '',
      is_default: [],
      urlRouter: '',
      urlRouterquery:{url: 'address'}
    }
  },
  created () {
    this.uid = this.$store.state.saveUData.uid
    this.urlRouter = this.$store.state.oldRouter
    console.log(this.$route)
    this.$getData({ uid: this.uid }, this.reqAddress).then(res => {
      // console.log(res);
      this.saveData = res.result
      this.saveData.forEach((e, ind) => {
        /// /console.log(e.is_default);
        this.is_default[ind] = e.is_default
      })
    })
  },
  beforeCreate: function () {
    document.getElementsByTagName('body')[0].className = 'bg-fff'
  },
  methods: {
    delAdd () {
      // console.log(this.delIndex);
      this.isDel = false
      let address_id = this.saveData[this.delIndex].id
      // console.log(this.reqDelete);

      this.$getData(
        { address_id: address_id, uid: this.uid },
        this.reqDelete
      ).then(res => {
        if (res.status == 'success') {
          // console.log("删除成功");
          this.saveData.splice(this.delIndex, 1)
        }
      })
    },
    updateAdd (index) {
      let url = window.location.href.split('/')[3]
      let address_id = this.saveData[index].id
      this.$router.push({path: '/add_address', query: {url: url, address: this.saveData[index]}})
    },
    delHide () {
      this.isDel = false
    },
    delShow (index) {
      this.delIndex = index
      this.isDel = true
    },
    updateAddress (index) {
      // console.log(index);
      this.$store.state.address = this.saveData[index]
      console.log(this.$store.state.address)
      this.$router.push(this.urlRouter)
    },
    setDefault (index) {
      let arr = this.is_default
      for (let index = 0; index < arr.length; index++) {
        arr[index] = false
      }
      let address_id = this.saveData[index].id
      // console.log(address_id);
      this.$getData(
        { address_id: address_id, uid: this.uid },
        this.reqUpdate
      ).then(res => {
        // console.log(res);
      })
    }
  }
}
</script>
