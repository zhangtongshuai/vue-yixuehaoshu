<template>
    <div >
        <!-- banner -->
<app-banner :listImg="listImg"></app-banner>
<!-- banner end -->
<!-- banner end -->

<!-- 商品名称和简介 -->
<div class="product_name">
    <h1><span>火热预售中!!!!!</span>这本书的名字叫做皮囊</h1>
    <p class="pro_pre">
        <span>截止日期：2018/12/11 23:59 </span><br>
        预售结束后，价格将调整为60.00元。<br>
        所有预售订单，将在2018年12月12日开始发货。
    </p>
    <div class="price">
        <div>
            <h2><span>￥</span>23.30</h2>
            <del>￥50.33</del>
            <h3>7.1折</h3>
        </div>
        <h4>销量：200</h4>
    </div>
    <div class="introduce">
        <ul>
            <li>
                <span class="span-nav">快递</span>
                <p>
                    <span v-if = "saveData.markets_one_fee == null || saveData.markets_one_fee.base_fee == 0">包邮<br></span> 
                <span v-if = "saveData.markets_one_fee != null && saveData.markets_one_fee.base_fee != 0">快递费：{{saveData.markets_one_fee.base_fee}}元<br></span> 
                <span v-if = "saveData.markets_one_fee != null && saveData.markets_one_fee.max_fee != 0"><font>满减</font>商品满{{saveData.markets_one_fee.max_fee}}元包邮</span></p>
            </li>
            <li>
                <span class="span-nav">出版日期</span>
                <p >{{saveData.produce_date}}</p>
            </li>
            <li>
                <span class="span-nav">作者</span>
                <p>{{saveData.author}}</p>
            </li>
            <li>
                <span class="span-nav">出版社</span>
                <p>{{saveData.manufactor}}</p>
            </li>
            <li>
                <span class="span-nav">页数</span>
                <p>{{saveData.pages}}</p>
            </li>
            <li>
                <span class="span-nav">ISBN/物品码</span>
                <p>{{saveData.code}}</p>
            </li>
        </ul>
    </div>
</div>
<!-- 商品名称和简介end -->

<!-- 联系供货商 -->
<div class="seller">
    <div class="seller_top" v-if="saveData.markets_one_member != null">
        <img :src = "saveData.markets_one_member.avatar">
        <div>
            <h1>{{saveData.markets_one_member.name}}</h1>
            <h2>{{saveData.markets_one_member.province_name}}{{saveData.markets_one_member.city_name}}</h2>
        </div>
    </div>
    <div class="seller_bot">
        <a class="contact_seller" @click="showContact()">联系供货商</a>
        <a href="#">返回比价</a>
    </div>
</div>
<!-- 联系供货商end -->
<!-- 联系供货商点击弹出框 -->
<div class="seller_contact" v-if="isShow">
    <div class="seller_contact_con">
        <div class="seller_contact_con_con">
            <div class="seller_contact_top">
                <img src="@/assets/img/Popup.png">
                <a id="seller_contact_close" @click="hideContact()">×</a>
            </div>
            <div class="seller_contact_bot">
                <div class="seller_contact_ewm">
                    <img :src="saveData.markets_one_member.qrcode">
                </div>
                <a :href="'tel:' + saveData.markets_one_member.mobile" v-show="saveData.markets_one_member.mobile !=0">电话：{{saveData.markets_one_member.mobile}} <button>拨打</button></a>
                <a v-show="saveData.markets_one_member.brief != ''">公告：{{saveData.markets_one_member.brief}}</a>
                <a>地址：{{saveData.markets_one_member.province_name}}{{saveData.markets_one_member.city_name}}{{saveData.markets_one_member.address}}</a>
            </div>
        </div>
    </div>
</div>
<!-- 联系供货商点击弹出框end -->

<!-- 详情 -->
<div class="details">
    <h1>【商品详情】</h1>
    <p v-html="saveData.brief"></p>
</div>
<!-- 详情end -->

<!-- 购买 -->
<div class="subnav">
    <div class="subnav_left">
        <a class="contact_seller" @click="showContact()">
            <img src="@/assets/img/menu6.png">
            <h4>客服</h4>
        </a>
        <router-link to="/shopping">
            <img src="@/assets/img/menu2.png">
            <h4>购物车</h4>
        </router-link>
    </div>
    <div class="subnav_right">
        <el-button :plain="true" @click="addShop()">加入购物车</el-button>
        <el-button :plain="true">立即购买</el-button>
        <!-- <a href="#">加入购物车</a>
        <a href="order_generate.html">立即购买</a> -->
    </div>
</div>
<!-- 购买end -->
    </div>
</template>
<script>
import Banner from "@/components/Banner";

export default {
  name: "product_details_yu",
  data() {
    return {
      saveData: [],
      request: {
        module: "market",
        method: "market.",
        request_mode: "get",
        page: 1
      },
      saveData: {},
      price: "",
      isShow: false,
      requestAdd: {
        module: "order",
        method: "cart",
        request_mode: "post",
        market_id: "",
        buyer: "",
        seller: "",
        market_name: "",
        market_number: "1",
        market_price: "",
        market_image: "",
        market_type: ""
      }
    };
  },
  created() {
    this.requestAdd.buyer = this.$store.state.saveUData.uid;
    let url = window.location.href.split("/")[4];
    this.request.method += url;
    //console.log(this.request);
    this.$getData({}, this.request).then(res => {
      //console.log(res);
      this.saveData = res.result;
      this.listImg = res.result.market_many_image;
      //console.log(res.result.produce_date);

      this.saveData.produce_date = res.result.produce_date.split(" ")[0];
      this.requestAdd.market_id = res.result.id;
    });
  },
  methods: {
    showContact() {
      this.isShow = true;
    },
    hideContact() {
      this.isShow = false;
    }
  },
  components: {
    "app-banner": Banner
  }
};
</script>

<style>

</style>
