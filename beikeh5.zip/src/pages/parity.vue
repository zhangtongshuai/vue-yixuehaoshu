<template>
  <div>
    <!-- 图书以及名称 -->
    <div class="book_name">
      <div class="book" ref="parityImg">
        <img :src="saveData.image">
      </div>
      <div class="name">
        <h1>{{saveData.name}}</h1>
      </div>
    </div>
    <!-- 图书以及名称end -->

    <!-- 选择供货商 -->
    <div class="choice">
      <h1>共有<span>{{saveData.markets_count}}家</span>供货商可以供您选择</h1>
      <div class="supplier">
        <ul>
          <li v-for='par in saveData.depot_many_markets'>
            <router-link :to="{name:'product_details',params:par}">
              <div class="supplier_left">
                <img :src="par.markets_one_member.avatar">
                <div class="title">
                  <h2>{{par.markets_one_member.name}}</h2>
                  <h3>{{par.markets_one_member.province_name}}{{par.markets_one_member.city_name}}</h3>
                </div>
              </div>
              <div class="supplier_right">
                <h2 v-if="par.market_type == 1"><span>￥</span>{{par.price}}</h2>
                <h2 v-if="par.market_type == 2"><span>￥</span>{{par.presale_price}}</h2>
                <h3 v-if="par.markets_one_fee == null || par.markets_one_fee.base_fee == 0">包邮</h3></h3>
                <h3 v-if="par.markets_one_fee != null && par.markets_one_fee.base_fee != 0">
                  快递费{{par.markets_one_fee.base_fee}}元
                  <p v-if="par.markets_one_fee.max_fee != 0">满{{par.markets_one_fee.max_fee}}元包邮</p></h3>
              </div>
            </router-link>
          </li>

        </ul>
        <div class="no_more">
          <span></span>
          <p>咩有了~</p>
          <span></span>
        </div>
      </div>
    </div>
    <!-- 选择供货商end -->

  </div>
</template>
<script>
export default {
  name: 'parity',
  data () {
    return {
      request: {
        module: 'market',
        method: 'market.contrast.',
        request_mode: 'get',
        page: 1
      },
      saveData: {},
      price: ''
    }
  },
  created () {
    let vm = this
    // this.request.method += this.$route.params.id
    this.request.method += window.location.href.split('/')[4]
    // console.log(this.parityId);
    this.$getData({}, this.request).then(res => {
      this.saveData = res.result
      if (vm.$store.state.oldRouter === 'product_details') {
        vm.$router.push({path: vm.$store.state.parityUrl})
      } else {
        vm.$store.state.parityUrl = vm.$store.state.RouterUrl
        console.log(vm.saveData.markets_count)
        if (vm.saveData.markets_count == 0) {
          vm.$router.push({path: vm.$store.state.parityUrl})
        } else if (vm.saveData.markets_count == 1) {
          console.log(vm.saveData.depot_many_markets[0])
          vm.$router.push({name: 'product_details', params: vm.saveData.depot_many_markets[0]})
        }
      }
    })
  }
}
</script>
<style>

</style>
