<template>
  <div class="search-box">
    <!-- 搜索 -->
    <div :class="searchBarFixed == true ? 'search search-fixed' :'search search-relative'" id="searchBar"
         :style = "isSubscribe ? TopNum52 : TopNum0 " >
      <img src="@/assets/img/search.png">
      <!-- <input type="text" placeholder="请输入物品码/商品名称" v-model="search"/> -->
      <el-input prefix-icon="el-icon-search" placeholder="请输入物品码/商品名称" v-model="search" clearable
                resize='none'></el-input>
      <button @click="proSearch()">搜索</button>
    </div>
    <!-- 搜索end -->
    <!-- 商品列表 -->
    <div class="product">
      <transition name="slide">
        <div id="wrapper" ref="scrollWrap" :class="isSubscribe ? 'top112' : 'top58'">
          <div class="scroller" ref="scroller">
            <!-- banner -->
            <app-banner :listImg="listImg" v-if="isBanner"></app-banner>
            <!-- banner end -->
            <app-search :data='scrollData'></app-search>
            <transition :name="loadingPosition">
              <!--v-show="showLoading"-->
              <Loading id="loading"  :class='{pullUpLoading}' ref="loading"
                       :loadingWord="loadingWord"></Loading>
            </transition>
            <div class="no_more" v-if="isWithout">
              <!--  -->
              <span></span>
              <p>咩有了~</p>
              <span></span>
            </div>

          </div>

        </div>
      </transition>
    </div>
  </div>
</template>
<script>
import Banner from '@/components/Banner'
import Search from '@/components/Search'
import BScroll from 'better-scroll'
import {getStyle, getDeviceRatio} from '@/assets/js/util.js'
import Loading from '@/components/loading.vue'
/* 获取当前缩放比 */
const DEVICE_RATIO = getDeviceRatio()

/**
   *
   * @param threshold 触发事件的阀值，即滑动多少距离触发
   * @param stop 下拉刷新后回滚
   */

/**
   * 上拉配置
   **/
const UP_CONFIG = {
  threshold: 60 * DEVICE_RATIO,
  stop: 40 * DEVICE_RATIO
}
export default {
  name: 'home',
  data () {
    return {
      listImg: [], // banner图数据
      searchBarFixed: true, //
      userData: '', // 用户数据
      scrollData: [], // 获取的设计
      search: '', // 绑定搜索框
      searchBar: '', // 监听搜索的
      searchData: '', // 传输的数据
      page: 1, // 页数
      request: {
        module: 'market',
        method: 'market',
        request_mode: 'get'
      },
      reqWxConfig: {
        method: 'wechat.share',
        module: 'member',
        request_mode: 'post'
      },
      sw: true, // 时间开关
      TopNum52: 'top:52px', // 是否关注css
      TopNum0: 'top:0px', // 是否关注css
      isWithout: false, // 数据是否存在
      scroller: null,
      center: true,
      pullUpLoading: false,
      showLoading: true,
      currentPage: 0,
      loadingWord: '正在加载',
      loadingPosition: '',
      isBanner: true, // banner 显示
      noMoreData: false,
      saveUData: {}
    }
  },
  computed: {
    isSubscribe () {
      return this.$store.getters.isSubscribe
    },
    // TopNum () {
    //   if (this.$store.getters.isSubscribe) { // 检测是否关注
    //     return '52px'
    //   } else {
    //     return '0px'
    //   }
    // }
  },
  created () {
    // 请求初始值
    this.$getData({page: this.page}, this.request).then(res => {
      if (res.code == '200') {
        this.scrollData = res.result
      }
      console.log(res)
    })

    // banner请求初始值
    this.$getData({}, {
      module: 'system',
      method: 'carousel',
      request_mode: 'get',
      page: 1
    }).then(res => {
      this.listImg = res.result
    })
  },
  mounted () {
    let vm = this
    // 注册scroll事件并监听
    window.addEventListener('scroll', this.handleScroll)
    const {scroller, scrollWrap, scrollList} = this.$refs
    /* 初始化scroll */
    this.scroller = new BScroll(scrollWrap, {
      click: true,
      probeType: 2,
      pullUpLoad: UP_CONFIG
    })
    /* 下拉刷新 */
    this.scroller.on('pullingDown', () => this.pullDown())

    /* 上拉加载更多 */
    this.scroller.on('pullingUp', () => this.pullUp())

    // // 搜索框位置
    // if (localStorage.getItem('userData') == null) {
    //   if (vm.isSubscribe) { // 检测是否关注
    //     vm.TopNum.top = '52px'
    //   } else {
    //     vm.TopNum.top = '0px'
    //   }
    // } else {
    //   if (vm.isSubscribe) { // 检测是否关注
    //     vm.TopNum.top = '52px'
    //   } else {
    //     vm.TopNum.top = '0px'
    //   }
    // }
  },
  watch: {
    data () {
      this.$nextTick(() => {
        this.scroller.refresh()
      })
    }
  },
  destroyed () {
    window.removeEventListener('scroll', this.handleScroll)
  },

  methods: {
    handleScroll () {
      let scrollTop =
          window.pageYOffset ||
          document.documentElement.scrollTop ||
          document.body.scrollTop
      let offsetTop = document.querySelector('#searchBar').offsetTop
      scrollTop += 108
      if (scrollTop > offsetTop) {
        this.searchBarFixed = true
      } else {
        this.searchBarFixed = false
      }
    },

    proSearch () {
      this.searchBar = this.search
      this.handleSearch(this.searchBar)
      // console.log('index')
    },
    handleSearch (val) {
      let vm = this
      let chinese = /^[\u4e00-\u9fa5]+$/
      if (val == '') {
        vm.request.code = ''
        vm.request.goods_name = ''
        this.isBanner = true
        vm.getProData({})
      } else if (!chinese.test(val) && val.split('').length === 13) {
        vm.request.code = val
        vm.request.goods_name = ''
        this.isBanner = false
        vm.getProData({})
      } else {
        vm.request.code = ''
        vm.request.goods_name = val
        this.isBanner = false
        vm.getProData()
      }

    },
    pullUp () {
      this.page++
      let vm = this

      this.showLoading = true
      console.log(this.noMoreData)
      if (!this.noMoreData) {
        this.beforeFetch('Up')
        setTimeout(() => {
          this.$getData({page: vm.page}, vm.request).then(res => {
            console.log(res)
            if (res.result.length > 0) {
              vm.scrollData = vm.scrollData.concat(res.result)
            } else {
              vm.isWithout = true
              vm.noMoreData = true
              this.showLoading = false
            }
            vm.afterFetch('Up')
            console.log(this.showLoading)
          }).catch((error) => {
            vm.afterFetch('Up')
          })
        }, 1000)
      } else {
        vm.afterFetch('Up')
      }
      console.log(this.showLoading)
    },
    getProData (value) {
      // 请求数据
      // 请求数据
      this.$getData(value, this.request).then(res => {
        if (res.code == '200') {
          this.scrollData = res.result
          this.isWithout = true
        }
      })
    },
    enable () {
      this.scroller && this.scroller.enable()
    },
    disable (type) {
      this.scroller && this.scroller.disable()
    },
    finishPullUp () {
      this.scroller && this.scroller.finishPullUp()
    },
    refresh () {
      this.scroller && this.scroller.refresh()
    },
    beforeFetch (type) {
      this[`pull${type}Loading`] = true
      this[`inPulling${type}`] = true
      this.showLoading = true
      if (type == 'Up') {
        this.loadingPosition = 'bot'
        this.loadingWord = '正在加载更多'
      }
    },
    afterFetch (type) {
      this.enable()
      this['finishPull' + type]()
      this.showLoading = false
      setTimeout(() => {
        this[`pull${type}Loading`] = false
      }, 300)
    }

  },
  components: {
    'app-banner': Banner,
    'app-search': Search,
    Loading

  }
}

</script>
<style lang="less">

</style>
