<template>
  <div>
    <app-header v-show="isSubscribe"></app-header>
    <router-view :class="isSubscribe ? 'box' : '' "></router-view>
    <footer-nav v-show="isNav"></footer-nav>
  </div>
</template>

<script>
import Footer from '../components/Footer'
import Header from '../components/Header'

export default {
  name: 'index',
  data () {
    return {
      userData: {},
      isNav: true,
      Subscribe: true,
      urlRouter: ''
    }
  },
  created () {
    this.userData = this.$store.state.saveUData
    let url = window.location.href.split('/')[3]
    // console.log(this.$store.state)
    console.log(this.$store.getters.isSubscribe)

    if (this.isSubscribe) {
      $('#wrapper').css('top', '80px')
    }
    if (
      url == '' ||
        url == 'home' ||
        url.indexOf('?code') != -1 ||
        url == 'my' ||
        url == 'classify' ||
        url == 'order' ||
        url == 'parity' ||
        url == 'classify_details'
    ) {
      this.isNav = true
    } else {
      this.isNav = false
    }
  },
  beforeCreate: function () {
    document.getElementsByTagName('body')[0].className = 'bg-f6'
  },
  beforeDestroy(){
    this.$store.state.oldRouter = this.urlRouter
  },
  watch: {
    $route (val) {
      console.log(val)
      console.log(this.$store.state.oldRouter)
      setTimeout(() => {
        this.$store.state.RouterUrl = val.fullPath
        this.$store.state.oldRouter = val.name
      },500)
      let url = window.location.href.split('/')[3]
      if (
        url == '' ||
          url == 'home' ||
          url.indexOf('?code') != -1 ||
          url == 'my' ||
          url == 'classify' ||
          url == 'order' ||
          url == 'parity' ||
          url == 'classify_details'
      ) {
        this.isNav = true
      } else {
        this.isNav = false
      }
    }
  },
  computed: {
    isSubscribe () {
      return this.$store.getters.isSubscribe
    }
  },
  methods: {
    showFollow () {
      // 弹出这个弹出框
      this.isPopup = true
    },
    hideFollow () {
      this.isPopup = false
    },
    showConcern () {
      this.isTe = flase
    },

    hideNav () {
      // 弹出这个弹出框
      this.isNav = false
    }
  },
  components: {
    'footer-nav': Footer,
    'app-header': Header
  }
}
</script>
