<template>
  <div>
    <!-- 分类 -->
    <div class="classify_details">
      <div class="demo">
        <div class="tabs">
          <div class="zhiding">
            <div class="classify_details_menu">{{detailsTitle}}</div>
            <ul class="tabs-list">
              <li v-for="(item,idx) in tabsNavList" @click="tabsClick(idx)" :class="{active: idx==indexPrev}">
                <a>{{item.sort}}</a>
              </li>
            </ul>
          </div>
          <div class="tabs-container">
            <div class="tab-content" style="display:block;">
              <transition name="slide">
                <div id="wrapper" ref="scrollWrap" style="bottom:40px;" :class="isSubscribe ? 'top157' : 'top112'">
                  <div class="scroller" ref="scroller">
                    <app-search :data='tabsList'></app-search>
                    <div class="no_more" v-if="isWithout">
                      <!--  -->
                      <span></span>
                      <p>咩有了~</p>
                      <span></span>
                    </div>
                  </div>
                </div>
              </transition>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 分类end -->
  </div>
</template>
<script>
import Search from '@/components/Search'
import BScroll from 'better-scroll'
import { getStyle, getDeviceRatio } from '@/assets/js/util.js'
import Loading from '@/components/loading.vue'

/* 获取当前缩放比 */
const DEVICE_RATIO = getDeviceRatio()

/**
 *
 * @param threshold 触发事件的阀值，即滑动多少距离触发
 * @param stop 下拉刷新后回滚
 */

/* 下拉配置 */
const DOWN_CONFIG = {
  threshold: 60 * DEVICE_RATIO,
  stop: 40 * DEVICE_RATIO
}
/* 上拉配置 */
const UP_CONFIG = {
  threshold: -60 * DEVICE_RATIO
}

export default {
  name: 'classify_details',
  data () {
    return {
      detailsTitle: '',
      isDel: true,
      indexPrev: 0,
      tabsNavList: [
        { sort: '综合', order_by_field: 'create_time' },
        { sort: '最新上架', order_by_field: 'create_time' },
        { sort: '销量优先', order_by_field: 'sales_number' },
        { sort: '出版时间', order_by_field: 'produce_date' }
      ],
      tabsList: [],
      request: {
        module: 'market',
        method: 'category.show',
        request_mode: 'get',
        category_id: '3',
        order_by_field: 'create_time',
        sequence: 'ASC'
      },
      isSubscribe: true,
      componentType: '',
      page: 1, // 页数
      isWithout: false, // 数据是否存在
      scroller: null,
      center: true,
      pullUpLoading: false,
      showLoading: false,
      currentPage: 0,
      loadingWord: '正在加载',
      loadingPosition: '',
      isWithout: false, // banner 显示
      noMoreData: false
    }
  },
  created () {
    this.detailsTitle = this.$route.params.name
    this.request.category_id = window.location.href.split('/')[4]
    console.log(this.$route.params.name)
    this.isSubscribe = !this.$store.state.saveUData.is_subscribe
    this.$getData({}, this.request).then(response => {
      // console.log(response);
      this.tabsList = response.result
      //     ////console.log(_this.tabsList);
    })
    /// /console.log(this.$route.params.name);
  },
  mounted () {
    // 注册scroll事件并监听
    window.addEventListener('scroll', this.handleScroll)
    const { scroller, scrollWrap, scrollList } = this.$refs
    /* 初始化scroll */
    this.scroller = new BScroll(scrollWrap, {
      click: true,
      probeType: 2,
      pullUpLoad: UP_CONFIG
    })
    /* 下拉刷新 */
    this.scroller.on('pullingDown', () => this.pullDown())

    /* 上拉加载更多 */
    this.scroller.on('pullingUp', () => this.pullUp())
  },
  watch: {
    data () {
      this.$nextTick(() => {
        this.scroller.refresh()
      })
    }
  },
  methods: {
    tabsClick (index) {
      this.indexPrev = index
      this.request.order_by_field = this.tabsNavList[index].order_by_field
      this.componentType = this.request.order_by_field
      this.isWithout = false
      if (this.request.sequence == 'DESC') {
        this.request.sequence = 'ASC'
      } else {
        this.request.sequence = 'DESC'
      }
      /// /console.log(this.response)
      this.$getData({}, this.request).then(response => {
        /// /console.log(response);
        this.tabsList = response.result
      })
    },
    pullUp () {
      this.page++
      let vm = this
      console.log(this.page)

      if (!this.noMoreData) {
        this.beforeFetch('Up')
        setTimeout(() => {
          this.$getData({ page: vm.page }, vm.request).then(res => {
            console.log(res.result.length)
            if (res.result.length > 0) {
              vm.tabsList = vm.tabsList.concat(res.result)
            } else if (res.result.length == 0) {
              vm.isWithout = true
              vm.noMoreData = true
            }
            vm.afterFetch('Up')
          })
            .catch((error) => {
              vm.afterFetch('Up')
            })
        }, 1000)
      }
    },
    enable () {
      this.scroller && this.scroller.enable()
    },
    disable (type) {
      this.scroller && this.scroller.disable()
    },
    finishPullUp () {
      this.scroller && this.scroller.finishPullUp()
    },
    refresh () {
      this.scroller && this.scroller.refresh()
    },
    beforeFetch (type) {
      this[`pull${type}Loading`] = true
      this[`inPulling${type}`] = true
      this.showLoading = true
      if (type == 'Up') {
        this.loadingPosition = 'bot'
        this.loadingWord = '正在加载更多'
      }
    },
    afterFetch (type) {
      this.enable()
      this['finishPull' + type]()
      this.showLoading = false
      setTimeout(() => {
        this[`pull${type}Loading`] = false
      }, 300)
    }

  },
  components: {
    'app-search': Search
  }
}

</script>
<style>

</style>
