<template>
    <div class="search-box">
      <div :class="searchBarFixed == true ? 'search search-fixed' :'search search-relative'" id="searchBar" :style = "TopNum">
      <img src="@/assets/img/search.png">
      <input type="text" placeholder="请输入物品码/商品名称"/>
      <button>搜索</button>
      </div>
      <div class="classify" :style = "TopNum">
        <ul class="tabs-list">
          <li v-for="a in saveNav" :key="a.id" :class="isActive == a.id ?  'active' : ''">
            <router-link  :to="/classify/+ a.id" @click = "ListCilck(a.id)">{{a.name}}</router-link>
          </li>

        </ul>
        <div class="tabs-container">
          <router-view></router-view>
        </div>
</div>
<!-- 分类end -->

    </div>
  </div>

</template>

<script>
export default {
  name: 'classify',
  data () {
    return {
      cc: -1,
      nav: [], // 获取到的数据
      saveNav: {},
      rightNav: [], // 传给右边路由的数据
      indexPrev: 0, // 判断点击事件
      searchBarFixed: true, // 滚动事件判断
      request: {
        module: 'market',
        method: 'category',
        request_mode: 'get',
        page: 1
      },
      TopNum: {
        top: ''
      }, // 是否关注css
      userData: {},
      isActive: 0
    }
  },
  computed:{
    isSubscribe () {
      return this.$store.getters.isSubscribe
    }
  },
  created () {
    this.userData = this.$store.state.saveUData
    this.isActive = this.$route.params.id
    console.log(this.isActive)
    if (this.isSubscribe) { // 检测是否关注
      this.TopNum.top = '52px'
    } else {
      this.TopNum.top = '0px'
    }
    this.$getData({}, this.request).then(res => {
      console.log(res.result)
      this.saveNav = res.result
      var arr = Object.keys(this.saveNav);
      this.$router.push('/classify/' + arr[0])
    })
  },
  watch: {
    $route (nVal, oVal) {
      console.log(nVal,oVal)
      this.isActive = nVal.params.id
      console.log(nVal.params.id)
    }
  },
  beforeCreate: function () {
    document.getElementsByTagName('body')[0].className = 'bg-f6'
  },
  mounted () {
    window.addEventListener('scroll', this.handleScroll)
  },
  destroyed () {
    window.removeEventListener('scroll', this.handleScroll)
  },

  methods: {
    handleScroll () {
      let scrollTop =
        window.pageYOffset ||
        document.documentElement.scrollTop ||
        document.body.scrollTop
      let offsetTop = document.querySelector('#searchBar').offsetTop
      scrollTop += 108
      if (scrollTop > offsetTop) {
        this.searchBarFixed = true
      } else {
        this.searchBarFixed = false
      }
    },
    ListCilck(val){
      this.isActive = val
    }

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
