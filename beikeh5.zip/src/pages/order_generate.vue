<template>
<div>
        <!-- 地址信息 -->
    <div class="order_address">
        <div class="order_address_con">
            <div class="order_bg1"></div>
            <div class="order_bg2"></div>
            <div class="order_address_top">
                <router-link v-if="isAddShow" to="/address">
                    <div class="link">
                        <div>
                            <i class="iconfont">&#xe65b;</i>
                            <span>收货人：</span>
                        </div>
                        <p>{{saveAddress.consignee}}（{{saveAddress.mobile}}）</p>
                    </div>
                    <div class="link">
                        <div>
                            <i class="iconfont">&#xe63e;</i>
                            <span>收货地址：</span>
                        </div>
                        <p>{{saveAddress.province}}{{saveAddress.city}}{{saveAddress.district}}{{saveAddress.address}}</p>
                    </div>
                </router-link>
                <router-link  v-else to="/add_address" class="wu_address">
                    <i class="iconfont">&#xe63e;</i>
                    <p>请先添加收货地址~</p>
                </router-link>
                <router-link class="right" to="/address">
                    <img src="@/assets/img/xia.png">
                </router-link>
            </div>
            <div class="order_bg3"></div>
            <div class="order_bg1"></div>
        </div>
    </div>
    <!-- 地址信息结束 -->

    <!-- 订单信息 -->
    <div class="order_info">
        <div class="order" v-for="(Shop,index) in saveShop">
            <div class="order_top">
                <div class="title">
                    <img :src="Shop.shop_avatar">
                    <h1>{{Shop.shop_name}}</h1>
                </div>
            <a class="contact_seller" @click="showContact(index)">联系卖家</a>
            </div>
            <a class="order_con">
                <div class="book" v-for="book in Shop.carts">
                    <div class="img"><img :src="book.market_image"></div>
                    <div class="title">
                        <h1>{{book.market_name}}</h1>
                        <h2>
                            <span v-if="book.market_type == 1">￥{{book.market_price}}</span>
                            <span v-else>￥{{book.market_presale_price}}</span>
                            <span>×{{book.cart_market_number}}</span></h2>
                    </div>
                </div>
            </a>
            <div class="tjr">
                <span>推荐人</span>
                <!-- <select>
                    <option value="1">杨洋</option>
                </select> -->
                <span v-if="Shop.referee != null">{{Shop.referee.name}} {{Shop.referee.mobile}}</span>
            </div>
            <div class="liuyan">
                <textarea rows="1" placeholder="请输入您的小要求~" v-model="NoteText[index]"></textarea>
            </div>
            <div class="order_bot">

                <h1>共计{{num[index]}}件商品，合计<span>￥{{sum[index]}}</span></h1>

                <h1>（含运费：￥{{fee[index]}}）</h1>
            </div>
        </div>

        <div class="order_tips">*支付前请先与对方确认交易细节！</div>
    </div>
    <!-- 订单信息end -->
    <!-- 支付 -->
    <div class="order_pay">
        <div class="pay_top">

            <h2>共计{{sumNum}}件商品，运费￥{{shipping}}</h2>
            <h1>￥<font>{{proSum}}</font></h1>
        </div>
        <div class="pay_bot">
            <span @click="back()">回首页</span>
            <span type="primary" @click="openFullScreen" v-loading.fullscreen.lock="fullscreenLoading">
                支付
            </span>
        </div>
    </div>
    <!-- 支付end -->
    <!-- 联系供货商点击弹出框 -->
<div class="seller_contact" v-if="isShow">
    <div class="seller_contact_con">
        <div class="seller_contact_con_con">
            <div class="seller_contact_top">
                <img src="@/assets/img/Popup.png">
                <a id="seller_contact_close" @click="hideContact()">×</a>
            </div>
            <div class="seller_contact_bot">
                <div class="seller_contact_ewm">
                    <img :src="saveShop[contactInd].shop_qrcode">
                </div>
                <a :href="':tel' + saveShop[contactInd].shop_mobile" v-show="saveShop[contactInd].shop_mobile !=0">电话：{{saveShop[contactInd].shop_mobile}} <button>拨打</button></a>
                <a v-show="saveShop[contactInd].shop_brief != ''">公告：{{saveShop[contactInd].shop_brief}}</a>
                <a v-if = 'saveShop[contactInd].shop_address != ""'>地址：{{saveShop[contactInd].shop_province}}{{saveShop[contactInd].shop_city}}{{saveShop[contactInd].shop_address}}</a>
                <a>地址：{{saveShop[contactInd].shop_province}}{{saveShop[contactInd].shop_city}}</a>
            </div>
        </div>
    </div>
</div>
<!-- 联系供货商点击弹出框end -->

</div>
</template>
<script>
export default {
  name: 'order_generate',
  data () {
    return {
      saveAddress: '',
      saveShop: '',
      uid: '',
      reqAddress: {
        request_mode: 'post',
        module: 'member',
        method: 'address.show_default'
      },
      reqOrder: {
        request_mode: 'post',
        module: 'order',
        method: 'cart.showById'
      },
      reqCartOrder: {
        request_mode: 'post',
        module: 'order',
        method: 'order.cart_order'
      },
      reqStoreCharge: {
        request_mode: 'post',
        module: 'order',
        method: 'order.store_charge',
        uid: '',
        total: '',
        order_id: ''
      },
      uid: '',
      isAddShow: false,
      isShow: false,
      contactInd: 0,
      pay: {},
      fullscreenLoading: false,
      NoteText: [],
      isAuthorized: true
    }
  },
  created () {
    let vm = this
    let state = this.$store.state
    vm.uid = state.saveUData.uid
    vm.isAuthorized = state.isAuthorized
    let cart_id = state.saveCartId.toString()
    if (state.address.length) {
      vm.saveAddress = state.address
      let address_id = state.address.id
      vm.$getData(
        { uid: vm.uid, cart_id: cart_id, address_id: address_id },
        vm.reqOrder
      ).then(res => {
        /// /console.log(res);
        state.address = res.result
        vm.saveAddress = state.address
        if (res.result != null) {
          vm.isAddShow = true
        }
      })
    } else {
      vm.$getData({ uid: vm.uid }, vm.reqAddress).then(res => {
        /// /console.log(res);
        let address_id = ''
        if (res.result != null) {
          vm.isAddShow = true
          state.address = res.result
          vm.saveAddress = state.address
          address_id = state.address.id
        } else {
          vm.isAddShow = false
          address_id = 0
        }
        let cart_id = state.saveCartId.toString()
        vm.$getData(
          { uid: vm.uid, cart_id: cart_id, address_id: address_id },
          vm.reqOrder
        ).then(res => {
          console.log(res.result);
          vm.saveShop = res.result
        })
      })
    }
  },
  computed: {
    sum () {
      let sum = []
      if (this.saveShop != '') {
        for (let i = 0; i < this.saveShop.length; i++) {
          if (this.saveShop[i].total > this.saveShop[i].fee.max_fee) {
            sum.push(parseFloat(this.saveShop[i].total))
          } else {
            sum.push(
              (
                parseFloat(this.saveShop[i].total) +
                parseFloat(this.saveShop[i].fee.base_fee)
              ).toFixed(2)
            )
          }
        }
      }

      return sum
    },
    fee () {
      let fee = []
      if (this.saveShop != '') {
        for (let i = 0; i < this.saveShop.length; i++) {
          if (this.saveShop[i].total > this.saveShop[i].fee.max_fee) {
            fee.push('0.00')
          } else {
            fee.push(this.saveShop[i].fee.base_fee)
          }
        }
      }

      return fee
    },
    num () {
      let num = []
      if (this.saveShop != '') {
        this.saveShop.forEach((e, index) => {
          let num1 = 0
          e.carts.forEach(Element => {
            num1 += Element.cart_market_number
          })
          num.push(num1)
        })
      }

      return num
    },
    sumNum () {
      let sumNum = 0
      if (this.saveShop != '') {
        this.saveShop.forEach(e => {
          e.carts.forEach(Element => {
            sumNum += Element.cart_market_number
          })
        })
      }

      return sumNum
    },
    shipping () {
      let shipping = 0
      if (this.fee != '') {
        this.fee.forEach(e => {
          shipping += parseFloat(e)
        })
      }

      return shipping.toFixed(2)
    },
    proSum () {
      let proSum = 0
      if (this.sum != '') {
        this.sum.forEach(e => {
          proSum += parseFloat(e)
        })
      }

      return proSum.toFixed(2)
    }
  },
  methods: {
    showContact (index) {
      this.contactInd = index
      this.isShow = true
    },
    hideContact () {
      this.isShow = false
    },
    back () {
      this.$router.push({ path: '/' })
    },
    openFullScreen () {
      this.fullscreenLoading = true
      this.subOrder()
      setTimeout(() => {
        this.fullscreenLoading = false
      }, 1500)
    },
    subOrder () {
      let state = this.$store.state
      let cart_id = state.saveCartId.toString()
      let address_id = state.address.id
      let openid = state.saveUData.openid
      console.log('shopData', state.shopData)
      let remark = ''
      remark = this.NoteText.join(',')
      if (this.NoteText.length == 0) {
        // console.log("NoteText1",this.NoteText.length);
        for (var i = this.saveShop.length - 1; i > 0; i--) {
          remark += ','
        }
      } else if (this.NoteText.length != state.shopData.length) {
        console.log('NoteText2', this.NoteText.length)
        for (var i = this.saveShop.length - 1; i > 0; i--) {
          remark += ','
        }
      }
      console.log('remark', remark)
      if (JSON.stringify(this.pay) == '{}') {
        this.$getData(
          {
            uid: this.uid,
            cart_id: cart_id,
            address_id: address_id,
            remark: remark
          },
          this.reqCartOrder
        ).then(res => {
          // this.pay = res.result;
          /// /console.log(res);
          // this.getPay(openid);
          this.reqStoreCharge.uid = this.uid
          this.reqStoreCharge.order_id = res.result.order_id
          this.reqStoreCharge.total = res.result.total
          this.$getData({}, this.reqStoreCharge).then(res => {
            this.pay = res.result
            /// /console.log(this.pay);
            this.getPay(openid)
          })
        })
      } else {
        this.getPay(openid)
      }
    },
    getPay (openid) {
      if (this.isAuthorized) {
        this.$http
          .get(
            'http://librarypay.zhongmeiyixue.com/wechat/mp?out_trade_no=' +
              this.pay.charge_no +
              '&body=1111&total_fee=' +
              Math.round(parseFloat(this.pay.amount) * 100) +
              '&openid=' +
              openid
          )
          .then(respon => {
            /// /console.log(respon.data);
            this.callpay(respon.data)
          })
      } else {
        window.location.href =
          'http://librarypay.zhongmeiyixue.com/alipay/wap?out_trade_no=' +
          this.pay.charge_no +
          '&total_amount=' +
          Math.round(parseFloat(this.pay.amount) * 100) +
          '&subject=企业图书馆支付订单'
      }
    },
    jsApiCall (result) {
      let _this = this
      WeixinJSBridge.invoke('getBrandWCPayRequest', result, function (res) {
        if (res.err_msg == 'get_brand_wcpay_request:ok') {
          _this.$message('支付成功')
          _this.$router.push({ path: '/order' })
        } else {
          _this.$message('支付失败')
        }
      })
    },
    callpay (res) {
      /// ///console.log(res)
      if (typeof WeixinJSBridge === 'undefined') {
        if (document.addEventListener) {
          document.addEventListener('WeixinJSBridgeReady', jsApiCall, false)
        } else if (document.attachEvent) {
          document.attachEvent('WeixinJSBridgeReady', jsApiCall)
          document.attachEvent('onWeixinJSBridgeReady', jsApiCall)
        }
      } else {
        this.jsApiCall(res)
      }
    }
    // onBridgeReady(resData) {
    //   WeixinJSBridge.invoke("getBrandWCPayRequest", resData, function(res) {
    //     if (res.err_msg == "get_brand_wcpay_request:ok") {
    //     } // 使用以上方式判断前端返回,微信团队郑重提示：res.err_msg将在用户支付成功后返回    ok，但并不保证它绝对可靠。
    //   });
    // }
  }
}
// function onBridgeReady() {
//   WeixinJSBridge.invoke(
//     "getBrandWCPayRequest",
//     {"appId":"wxecbdd99e6e605612","timeStamp":"1524730724","nonceStr":"XXPTYoe36lZ0Pp75","package":"prepay_id=wx261618450659972a1d9ff1c40097012452","signType":"MD5","paySign":"8FE81501CFFF0232CEF2DC4EDB890414"},
//     function(res) {
//       if (res.err_msg == "get_brand_wcpay_request:ok") {
//       } // 使用以上方式判断前端返回,微信团队郑重提示：res.err_msg将在用户支付成功后返回    ok，但并不保证它绝对可靠。
//     }
//   );
// }
// if (typeof WeixinJSBridge == "undefined") {
//   if (document.addEventListener) {
//     document.addEventListener("WeixinJSBridgeReady", onBridgeReady, false);
//   } else if (document.attachEvent) {
//     document.attachEvent("WeixinJSBridgeReady", onBridgeReady);
//     document.attachEvent("onWeixinJSBridgeReady", onBridgeReady);
//   }
// } else {
//   onBridgeReady();
// }
</script>
<style>

</style>
