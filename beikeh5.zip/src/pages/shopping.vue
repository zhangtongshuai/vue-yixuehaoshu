<template>
  <div>
    <!-- 购物车 -->
    <div class="shopping" v-if="saveData.length != 0">
      <div class="shop_seller" v-for="(info,index) in saveData" v-if="info.carts.length">
        <div class="title">
          <img :src="info.shop_avatar">
          <h1>{{info.shop_name}}</h1>
          <label><input type="checkbox" name="all" @click="chooseShopGoods(index)" v-model="info.checked"><span></span></label>
        </div>
        <div class="product" v-for="(pro,key) in info.carts">
          <div class="checkbox">
            <label><input type="checkbox" name="all" v-model="pro.checked" @click="choose(index, key)"
                          :value="pro.cart_id"></label>

          </div>
          <div class="img"><img :src="pro.market_image"
                                onerror="this.src = 'http://api.store.zhongmeiyixue.com/5ad8449b67fb0.jpg'"></div>
          <div class="name">
            <h1>{{pro.market_name}}</h1>
            <h2>
              <font>￥{{pirce[index][key]}}</font>
              <!--<el-input-number size="mini" v-model="pro.cart_market_number" @change="handleChange(index,key)" :min="1"-->
                               <!--:max="pro.market_number" label="描述文字"></el-input-number>-->
              <div>
                <span @click="redu(index,key)">-</span>
                <input type="text" v-model="pro.cart_market_number" v-on:blur="handleChange(index,key)" />
                <span @click="add(index,key)">+</span>
              </div>
            </h2>
          </div>
          <div class="delete"><i class="iconfont" @click="delBounce(index,key)">&#xe792;</i></div>
        </div>

      </div>

      <div class="no_more">
        <span></span>
        <p>咩有了~</p>
        <span></span>
      </div>
    </div>
    <!-- 购物车end -->
    <!-- 暂无 -->
    <div class="zanwu" v-else>
      <img src="@/assets/img/Popup3.png">
      <p>哎呀，暂时没有内容~</p>
    </div>
    <!-- 暂无 end -->
    <!-- 支付 -->
    <div class="pay">
      <div class="pay_top">
        <div @click="chooseAllGoods()">
          <label><input type="checkbox" v-model="allChecked"><span></span></label>
          <h2>全选</h2>
        </div>
        <h1>￥<font>{{totalMoney}}</font></h1>
      </div>
      <div class="pay_bot">
        <router-link to="/"> 回首页</router-link>
        <router-link to="/order_generate" v-if="saveData.length != 0">去支付</router-link>
        <router-link to="/shopping" v-else>去支付</router-link>
      </div>
    </div>
    <!-- 支付end -->
    <!--删除-->
    <div class="seller_contact2" v-show="isDel">
      <div class="seller_contact_con">
        <div class="seller_contact_con_con">
          <div class="seller_contact_top">
            <img src="@/assets/img/Popup.png">
            <a id="seller_contact_close" @click="delHide()">×</a>
          </div>
          <div class="seller_contact_bot">
            <p>真的要删除这件商品吗？</p>
          </div>
          <div class="seller_contact_button">
            <a @click="delShow()">是真的要删</a>
            <a class="seller_delete" @click="delHide()">算了不删了</a>
          </div>
        </div>
      </div>
    </div>
    <!--删除结束-->
  </div>
</template>

<script>
let _list = []
export default {
  name: 'shopping',
  data () {
    return {
      saveData: [],
      listItem: [],
      checkAll: false,
      isIndeterminate: true,
      request: {
        module: 'order',
        method: 'cart.show',
        request_mode: 'get'
      },
      requestUpdate: {
        module: 'order',
        method: 'cart.update',
        request_mode: 'post',
        market_id: '',
        number: '',
        cart_id: ''
      },
      requestDelete: {
        module: 'order',
        method: 'cart.delete',
        request_mode: 'post',
        cart_id: ''
      },
      totalMoney: 0,
      totalFare: 0,
      allChecked: false,
      userData: {},
      isDel: false,
      delIndex: []
    }
  },
  created () {
    //   let isSubscribe = this.$customMethods.getAllUrlPram(localStorage.getItem('isCode'))
    console.log(this.saveData.length)
    console.log(this.$store.state)
    this.userData = this.$store.state.saveUData
    this.request.uid = this.userData.uid
    this.requestUpdate.uid = this.userData.uid
    this.requestDelete.uid = this.userData.uid
    this.$getData({}, this.request).then(res => {
      if (res.status == 'success') {
        this.saveData = res.result
        this.$store.state.shopData = this.saveData
      }else{
        console.log(res.msg)
      }
    })
  },

  computed: {
    pirce () {
      let pirce = []
      if (this.saveData.length != 0) {
        this.saveData.forEach((e, k) => {
          let shopPice = []
          for (let i = 0; i < e.carts.length; i++) {
            if (e.carts[i].market_type == '2') {
              shopPice.push(e.carts[i].market_presale_price)
            } else {
              shopPice.push(e.carts[i].market_price)
            }
          }
          pirce.push(shopPice)
        })
      }
      return pirce
    }
  },
  beforeCreate: function () {
    document.getElementsByTagName('body')[0].className = 'bg-fff'
  },
  beforeDestroy: function () {
    document.body.removeAttribute('class', 'active')
  },
  methods: {
    add (key, value) {
      this.requestUpdate.market_id = this.saveData[key].carts[value].market_id
      this.requestUpdate.number = this.saveData[key].carts[value].cart_market_number + 1
      this.requestUpdate.cart_id = this.saveData[key].carts[value].cart_id
      console.log(this.requestUpdate)
      this.$getData({}, this.requestUpdate).then(res => {
        if (res.status == 'success') {
          this.$getData({}, this.request).then(res => {
            this.saveData = res.result
            this.$store.state.shopData = this.saveData
          })
        }
      })
    },
    redu (key, value) {
      this.requestUpdate.market_id = this.saveData[key].carts[value].market_id
      this.requestUpdate.number = this.saveData[key].carts[value].cart_market_number - 1
      this.requestUpdate.cart_id = this.saveData[key].carts[value].cart_id
      this.$getData({}, this.requestUpdate).then(res => {
        if (res.status == 'success') {
          this.$getData({}, this.request).then(res => {
            this.saveData = res.result
            this.$store.state.shopData = this.saveData
          })
        }
      })
    },
    handleChange (key, value) {
      this.requestUpdate.market_id = this.saveData[key].carts[value].market_id
      this.requestUpdate.number = this.saveData[key].carts[value].cart_market_number
      this.requestUpdate.cart_id = this.saveData[key].carts[value].cart_id
      this.$getData({}, this.requestUpdate).then(res => {
        console.log(res)
        if (res.status === 'success') {
          this.$getData({}, this.request).then(res => {
            this.saveData = res.result
            this.$store.state.shopData = this.saveData
          })
        } else {
          this.$message.error(res.msg)
          this.$getData({}, this.request).then(res => {
            this.saveData = res.result
            this.$store.state.shopData = this.saveData
          })
        }
      })
    },
    delBounce (index, key) {
      this.delIndex = [index, key]
      this.isDel = true
      console.log(this.delIndex)
    },
    delHide () {
      this.isDel = false
    },
    delShow () {
      this.isDel = false
      let index = this.delIndex[0]
      let key = this.delIndex[1]
      console.log(this.saveData[index].carts[key])
      this.requestDelete.cart_id = this.saveData[index].carts[key].cart_id

      this.$getData({},
        this.requestDelete
      ).then(res => {
        if (res.status == 'success') {
          // console.log("删除成功");
          this.saveData[index].carts.splice(key, 1)
        }
      })
      console.log('删除成功')
    },
    // 全部商品全选
    chooseAllGoods: function () {
      var flag = false
      if (this.allChecked) {
        flag = true
      }
      if (this.saveData.length != 0) {
        for (var i = 0, len = this.saveData.length; i < len; i++) {
          this.saveData[i]['checked'] = flag
          var list = this.saveData[i]['carts']
          for (var k = 0, len1 = list.length; k < len1; k++) {
            list[k]['checked'] = flag
          }
        }
      }
      this.allChecked = !this.allChecked
      this.saveCart()
      this.calTotalMoney()
    },

    // 每个店铺全选
    chooseShopGoods: function (index) {
      var list = this.saveData[index]['carts'],
        len = list.length
      if (this.saveData.length != 0) {
        if (this.saveData[index]['checked']) {
          for (var i = 0; i < len; i++) {
            list[i]['checked'] = false
          }
        } else {
          for (var i = 0; i < len; i++) {
            list[i]['checked'] = true
          }
        }
      }
      this.saveData[index]['checked'] = !this.saveData[index]['checked']

      // 判断是否选择所有商品的全选
      this.isChooseAll()

      this.cal(index)
    },

    // 单个选择
    choose: function (index1, index) {
      var list = this.saveData[index1]['carts'],
        len = list.length
      if (list[index]['checked']) {
        this.saveData[index1]['checked'] = false
        this.allChecked = false
        list[index]['checked'] = !list[index]['checked']
      } else {
        list[index]['checked'] = !list[index]['checked']

        // 判断是否选择当前店铺的全选
        var flag = true
        for (var i = 0; i < len; i++) {
          if (list[i]['checked'] == false) {
            flag = false
            break
          }
        }
        flag == true
          ? (this.saveData[index1]['checked'] = true)
          : (this.saveData[index1]['checked'] = false)
      }

      // 判断是否选择所有商品的全选
      this.isChooseAll()

      this.cal(index)
    },

    // 判断是否选择所有商品的全选
    isChooseAll: function () {
      var flag1 = true
      if (this.saveData.length != 0) {
        for (var i = 0, len = this.saveData.length; i < len; i++) {
          if (this.saveData[i]['checked'] == false) {
            flag1 = false
            break
          }
        }
      }
      flag1 == true ? (this.allChecked = true) : (this.allChecked = false)
    },
    // 保存选中的id
    saveCart: function () {
      var oThis = this
      this.totalMoney = 0
      var cart = []
      if (this.saveData.length != 0) {
        for (var i = 0, len = this.saveData.length; i < len; i++) {
          var list = this.saveData[i]['carts']
          list.forEach(function (item, index, arr) {
            if (list[index]['checked']) {
              cart.push(item.cart_id)
              oThis.$store.state.saveCartId = cart
            }
          })
        }
      }
    },

    // 计算商品总金额
    calTotalMoney: function () {
      var oThis = this
      this.totalMoney = 0
      // console.log(this.totalMoney)
      if (this.saveData.length != 0) {
        for (var i = 0, len = this.saveData.length; i < len; i++) {
          var list = this.saveData[i]['carts']
          list.forEach(function (item, index, arr) {
            /// /console.log(item)

            if (list[index]['checked']) {
              if (item.market_type == '2') {
                oThis.totalMoney += parseFloat(item.market_presale_price) * parseFloat(item.cart_market_number)
              } else {
                oThis.totalMoney += parseFloat(item.market_price) * parseFloat(item.cart_market_number)
              }
            }
          })
        }
      }
    },

    // 计算方法集合
    cal () {
      this.saveCart()
      this.calTotalMoney()
    }
  }
}
</script>
