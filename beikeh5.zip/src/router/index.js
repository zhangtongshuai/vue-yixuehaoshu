import Vue from 'vue'
import Router from 'vue-router'
import index from '@/pages/index'
import home from '@/pages/home'
import classify from '@/pages/classify'
import shopping from '@/pages/shopping'
import order from '@/pages/order'
import my from '@/pages/my'
import tab from '@/components/tab'
import classify_details from '@/pages/classify_details'
import parity from '@/pages/parity'
import product_details from '@/pages/product_details'
import product_details_yu from '@/pages/product_details_yu'
import order_generate from '@/pages/order_generate'
import order_generate_direct from '@/pages/order_generate_direct'
import order_details from '@/pages/order_details'
import address from '@/pages/address'
import add_address from '@/pages/add_address'

Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [
    {
      path: '/',
      name: 'index',
      component: index,
      redirect: '/home',
      children: [
        {
          path: '/home',
          name: 'home',
          component: home
        },
        {
          path: '/classify',
          name: 'classify',
          component: classify,
          children: [{
            path: '/classify/:id',
            name: 'tab',
            component: tab
          }]
        },
        {
          path: '/shopping',
          name: 'shopping',
          component: shopping
        },
        {
          path: '/order',
          name: 'order',
          component: order
        },
        {
          path: '/order_generate',
          name: 'order_generate',
          component: order_generate
        },
        {
          path: '/order_details/:id',
          name: 'order_details',
          component: order_details
        },
        {
          path: '/order_generate_direct',
          name: 'order_generate_direct',
          component: order_generate_direct
        },
        {
          path: '/my',
          name: 'my',
          component: my
        },
        {
          path: '/classify_details/:id',
          name: 'classify_details',
          component: classify_details
        },
        {
          path: '/parity/:id',
          name: 'parity',
          component: parity
        },
        {
          path: '/product_details/:id',
          name: 'product_details',
          component: product_details
        },
        {
          path: '/product_details_yu/:id',
          name: 'product_details_yu',
          component: product_details_yu
        },
        {
          path: '/address',
          name: 'address',
          component: address
        },
        {
          path: '/add_address',
          name: 'add_address',
          component: add_address
        }
      ]
    }

  ]
})
