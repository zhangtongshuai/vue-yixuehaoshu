<template>
  <div>
    <ul v-if="data.length != 0">
      <li v-for="(list,listKey) in data">
        <router-link :to="{name:'parity',params:list}">
          <div class="productLeft" ref="proImg"><img :src="list.image" onerror="this.src = 'http://static.beikeshushe.com/5ad8449b67fb0.jpg'"></div>
          <div class="productRight">
            <h1>{{list.name}}</h1>
            <div class="price">
              <h2>￥{{price[listKey]}}</h2>
              <del v-show="list.min_price != null || list.min_presale_price !=null ">￥{{list.price}}</del>
            </div>
          </div>
        </router-link>
      </li>
    </ul>
    <!-- 暂无 -->
    <div class="zanwu" v-else>
      <img src="@/assets/img/Popup3.png">
      <p>哎呀，暂时没有内容~</p>
    </div>
    <!-- 暂无 end -->
  </div>
</template>
<script>
export default {
  props: ['data'],
  data () {
    return {
      loading2: true,
      proImgHeight: 0,
      request: {},
      reqIndex: {
        module: 'market',
        method: 'market',
        request_mode: 'get',
        page: 1
      },
      reqClassify: {
        module: 'market',
        method: 'category.show',
        request_mode: 'get',
        page: 1,
        category_id: '3',
        order_by_field: 'create_time'
      },
      isWithout: false,
      page: 1

    }
  },
  computed: {
    price () {
      let price = []
      if (this.$props.data != null) {
        this.$props.data.forEach(i => {
          if (i.min_price == null && i.min_presale_price != null) {
            price.push(i.min_presale_price)
          } else if (i.min_presale_price == null && i.min_price != null) {
            price.push(i.min_price)
          } else if (i.min_presale_price == null && i.min_price == null) {
            price.push(i.price)
          } else if (i.min_presale_price > i.min_price) {
            price.push(i.min_price)
          } else {
            price.push(i.min_presale_price)
          }
        })
      }
      return price
    }
  },
}

</script>
<style>

</style>
