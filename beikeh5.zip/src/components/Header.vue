<template>
  <div>
    <!-- 未关注显示 -->
    <div class="notFollow" @click="showFollow() ">
      <div class="notLeft">
        <img src="@/assets/img/logo.jpg">
        <h1>关注公众号，发现更多好书</h1>
      </div>
      <a href="#"><img src="@/assets/img/follow.png">关注</a>
    </div>
    <!-- 未关注显示end -->
    <!-- 未关注点击弹出框 -->
    <div class="Popup follow" v-if="isPopup">
      <div class="PopupCon">
        <div class="PopupConCon">
          <div class="PopupConTop">
            <img src="@/assets/img/Popup2.png">
            <a id="ClosePopup" @click="hideFollow()">×</a>
          </div>
          <div class="PopupConBottom">
            <div class="PopupConBottomEwm">
              <img src="@/assets/img/ewm.jpg">
            </div>
            <p>长按识别二维码<br>关注<span>“贝壳书社”</span>公众号</p>
          </div>
        </div>
      </div>
      <!-- 未关注点击弹出框end -->

    </div>
  </div>
</template>
<script>

export default {
  name: 'Header',
  data () {
    return {
      isPopup: false,
      isTe: true,
      boxPosition: true,
      isNav: true,
      screenHeight: 0,
      isClassName: false,
      parityId: ''
    }
  },
  methods: {
    showFollow () {
      // 弹出这个弹出框
      this.isPopup = true
    },
    hideFollow () {
      this.isPopup = false
    },
    showConcern () {
      this.isTe = flase
    },
    hideNav () {
      // 弹出这个弹出框
      // console.log(666);
      this.isNav = false
    }
  }
}
</script>
