<template>
  <div class="seller_contact2">
    <div class="seller_contact_con">
        <div class="seller_contact_con_con">
            <div class="seller_contact_top">
                <img src="@/assets/img/Popup.png">
                <a id="seller_contact_close"  @click="PayHide()">×</a>
            </div>
            <div class="seller_contact_bot">
                <p>支付~</p>
            </div>
            <div class="seller_contact_button">
                <a @click="PayOrder()">确定</a>
                <a class="seller_delete" @click="PayHide()">取消</a>
            </div>
        </div>
    </div>
</div>  
</template>

<script>
export default {
  props: ["data"],
  data() {
    return {
      popupList: [{ state: "确定" }, { state: "取消" }, { state: "支付" }]
    }
  },
  methods:{

  }
};
</script>
