<template>
    <iframe :src = ''>
        <p >您的浏览器不支持  iframe 标签。</p>
    </iframe>
</template>

<script>
export default {
    methods:{
        //setTimeout(this.toLogin(), 3000);
    }
}
</script>
