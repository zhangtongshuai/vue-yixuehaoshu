<template>
    <div id="banner" :class=" isMarTop == true ? 'mt52' :''">
        <swiper :options="swiperOption">
            <swiper-slide v-for="(str,key) in listImg" data-swiper-autoplay="3000"><img :src="str.image" style="width:100%;height:100%;"></swiper-slide> 
        <div class="swiper-pagination" slot="pagination"></div>
        
        </swiper>
        
    </div>
</template>
<script>
import { swiper, swiperSlide } from "vue-awesome-swiper";
import "swiper/dist/css/swiper.css";
export default {
  props: ["listImg"],
  data() {
    return {
      swiperOption: {
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
          autoplay: true
        },
        autoplay: {
          delay: 3000,
          stopOnLastSlide: false,
          disableOnInteraction: true
        },
        loop: true,
        loopAdditionalSlides: 1
      },
      isMarTop:false,
    };
  },
  created(){
      
      // let href = window.location.href.split("/");
      // if(href[3] != ''){
      //   this.isMarTop = false
      // }
  },
  components: {
    swiper,
    swiperSlide
  }
};
</script>