<template>
  <div class="tab-content">
    <div v-for='i in navCont'>

      <h4>{{i.name}}
        <router-link :to="{name:'classify_details',params:{ id: i.id, name: i.name}}">ALL>>
        </router-link>
      </h4>
      <div v-if="i.pid != undefined">
        <div class="classify_three">
          <router-link class="classify_three_a" v-for="t in i.children" :to="{name:'classify_details',params:{ id: t.id, name:t.name}}"
                       :style="{width:ImgWidth,height:ImgHeight + 'px'}">
            └─{{t.name}}
          </router-link>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'tab',
  data () {
    return {
      navCont: [],
      classifyTitle: '',
      request: {
        module: 'market',
        method: 'category',
        request_mode: 'get',
        page: 1
      },
      imgWidth: '',
      tabIndex: 0
    }
  },
  computed: {
    ImgWidth () {
      return this.imgWidth
    },
    ImgHeight () {
      return this.ImgWidth
    }
  },
  created(){
    this.tabIndex = this.$route.params.id
    this.getData()
  },
  watch: {
    $route (val) {
      this.tabIndex = val.params.id
      this.getData()
      this.classifyTitle = this.navCont.name
    }
  },
  methods: {
    getData () {
      this.$getData({}, this.request).then(res => {
        if (res.status == 'success') {
          this.navCont = res.result[this.tabIndex].children
          console.log(this.navCont)
        } else {
          alert(res.msg)
        }
      })
    }
  }
}
</script>
<style>

</style>
