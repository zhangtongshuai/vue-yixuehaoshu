<template>
  <div class="nav">
			<router-link to="/classify" class="nav-pic" active-class = 'active nav-pic'>
				<i class="iconfont">&#xe60a;</i>
				<h4>分类</h4>
			</router-link>
			<router-link to="/shopping" class="nav-pic" active-class = 'active nav-pic'>
				<i class="iconfont">&#xe64c;</i>
				<h4>购物车</h4>
			</router-link>
			<router-link to="/home" class="nav-pic" exact-active-class = 'active nav-pic'>
				<div class="index">
					<img src="@/assets/img/menu3.png" class="imgOne">
					<img src="@/assets/img/menu33.png" class="imgTwo">
				</div>
				<h4>首页</h4>
			</router-link>
			<router-link to="/order" class="nav-pic" active-class = 'active nav-pic'>
				<i class="iconfont">&#xe638;</i>
				<h4>订单</h4>
			</router-link>
			<router-link to="/my" class="nav-pic" active-class = 'active nav-pic'>
				<i class="iconfont">&#xe65b;</i>
				<h4>我的</h4>
			</router-link>
		</div>
</template>
<script>
export default {
  data () {
	  return {
		  isNav: true
	  }
  }

}
</script>

<style>

</style>
